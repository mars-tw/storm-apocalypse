import {
  AbstractMesh,
  AnimationGroup,
  ArcRotateCamera,
  AssetContainer,
  Color3,
  Color4,
  Constants,
  DefaultRenderingPipeline,
  DirectionalLight,
  DynamicTexture,
  Engine,
  GlowLayer,
  HemisphericLight,
  Layer,
  LoadAssetContainerAsync,
  Material,
  Matrix,
  Mesh,
  MeshBuilder,
  ParticleSystem,
  PBRMaterial,
  PointLight,
  PointerEventTypes,
  Ray,
  Scene,
  SceneInstrumentation,
  ShadowGenerator,
  StandardMaterial,
  Texture,
  TransformNode,
  Vector2,
  Vector3,
  VertexBuffer,
  VertexData,
} from "@babylonjs/core";
import "@babylonjs/loaders/glTF";
import type { ProceduralAudio } from "./audio";
import { COMBAT_POSITIONS, COMBAT_TIMING, enemyAttackTimings, enemyCombatStats, enemySpawnPosition, playerAttackStats, resolvedPlayerHitDamages, towerCombatStats } from "./combatRules";
import { BAIT_RULES, baitAttractedIndices, comboExpired, createCombo, gradeWave, pickBaitSource, registerComboKill, runAdvice, WAVE_GRADE_LABEL } from "./feedback";
import { EMPLOYEES, NAMED_CUSTOMERS, PROTAGONISTS, SHOP_UNLOCK_CHAPTER, TOWERS, WAVE_DISPATCHES, WAVE_EVE_DISPATCHES, WEAPONS, hasCompletedChapter, towerCostForState } from "./content";
import { InputController } from "./input";
import { awardPatrol, baitDrag, loadPatrol, savePatrol, selectSupply, supplyEffects, type SupplyId } from "./patrol";
import { resolveQuality, type QualityLevel, type QualityPreference } from "./quality";
import { addLoopProgress, assignLoopQuest, updateMainQuests } from "./quests";
import type { PlayerSettings } from "./settings";
import { creditIncome, saveState, type EmployeeId, type NamedCustomerId, type ProtagonistId, type RuntimeState, type TowerId, type WeaponId } from "./state";
import type { UiController } from "./ui";
import { enemyTypeForWave, getWavePlan, type DirectorZombieType, type WavePlan } from "./waveDirector";
import { parseWeatherIntensity, productionWeatherIntensity, WEATHER_ADAPTIVE_DENSITY, WEATHER_PROFILES, WEATHER_QUALITY_DENSITY, weatherBehaviorSignature, type WeatherIntensity, type WeatherProfile } from "./weather";

interface Actor {
  root: TransformNode;
  meshForwardNode: TransformNode;
  meshForwardAxis: Vector3;
  animations: AnimationGroup[];
  currentAnimation: string;
}

interface CowActor extends Actor {
  hp: number;
  maxHp: number;
  meatYield: number;
  strong: boolean;
  alive: boolean;
  isMoving: boolean;
  behaviorTimer: number;
  roamTarget: Vector3;
  pastureCenter: Vector3;
}

type ZombieType = DirectorZombieType;
type DamageSource = "player" | TowerId;

interface ZombieActor extends Actor {
  hp: number;
  maxHp: number;
  alive: boolean;
  speed: number;
  baseSpeed: number;
  attackTimer: number;
  attackPhase: "approach" | "anticipation" | "recovery";
  damage: number;
  reward: number;
  type: ZombieType;
  slowTimer: number;
  deathEndsAt: number;
  animationLodPaused: boolean;
  baitUntil: number;
  flashUntil: number;
}

interface MeatBait {
  root: TransformNode;
  ring: Mesh;
  position: Vector3;
  expiresAt: number;
}

interface PendingPlayerAttack {
  weapon: WeaponId;
  elapsed: number;
  impactAt: number;
  recoveryAt: number;
  resolved: boolean;
}

interface CameraSafeFrame {
  width: number;
  height: number;
  canvasTop: number;
  left: number;
  right: number;
  top: number;
  bottom: number;
  portraitBlend: number;
}

interface MeatDrop {
  root: TransformNode;
  baseY: number;
  phase: number;
  expiresAt: number;
}

interface TransientCombatVfx {
  mesh: Mesh;
  age: number;
  duration: number;
  startScale: number;
  endScale: number;
}

interface Projectile {
  root: TransformNode;
  target: ZombieActor;
  progress: number;
  start: Vector3;
  source: TowerId;
  damage: number;
  splash: number;
  slow: number;
}

interface TowerActor extends Actor {
  id: TowerId;
  weapon: TransformNode;
  pad: Mesh;
  cooldown: number;
  animationLodPaused: boolean;
}

interface StaffActor extends Actor {
  id: EmployeeId;
  timer: number;
  patrolIndex: number;
  attackTarget?: CowActor;
  attackImpactTimer: number;
}

type WorldPickAction =
  | { type: "tower"; id: TowerId }
  | { type: "employee"; id: EmployeeId }
  | { type: "pasture"; id: "pasture2" };

interface StormMetadata {
  stormStatic?: boolean;
  stormAction?: WorldPickAction;
}

type CustomerPhase = "hidden" | "arriving" | "buying" | "leaving";
type AnonymousCustomerVariant = "anonymous-traveler" | "anonymous-forager" | "anonymous-refugee";

interface CustomerActor extends Actor {
  phase: CustomerPhase;
  timer: number;
  identity: NamedCustomerId | null;
}

const R8_ZOMBIE_MODELS = [
  "custom/zombies/zombie-ash.glb",
  "custom/zombies/zombie-frost.glb",
  "custom/zombies/zombie-rust.glb",
] as const;

const R10_STAFF_MODELS: Record<EmployeeId, string> = {
  hunter: "custom/characters/staff-hunter.glb",
  cashier: "custom/characters/staff-cashier.glb",
  dog: "custom/characters/staff-shepherd-dog.glb",
};

const R10_ANONYMOUS_CUSTOMERS: ReadonlyArray<{ id: AnonymousCustomerVariant; model: string }> = [
  { id: "anonymous-traveler", model: "custom/characters/customer-traveler.glb" },
  { id: "anonymous-forager", model: "custom/characters/customer-forager.glb" },
  { id: "anonymous-refugee", model: "custom/characters/customer-refugee.glb" },
];

const R13_WORLD_MODELS = {
  cowBrown: "custom/world/cow-brown.glb",
  cowStrong: "custom/world/cow-strong.glb",
  pines: [
    "custom/world/pine-sentinel.glb",
    "custom/world/pine-windswept.glb",
    "custom/world/pine-young.glb",
  ],
  rocks: ["custom/world/rock-shelf.glb", "custom/world/rock-spire.glb"],
  fence: "custom/world/fence-rail.glb",
  gate: "custom/world/fence-gate.glb",
  snowhouse: "custom/world/snowhouse-shell.glb",
  snowhouseDoor: "custom/world/snowhouse-door.glb",
  snowhouseWindow: "custom/world/snowhouse-window.glb",
} as const;

const R13_VFX_FILES = [
  "snow-burst-a.png", "snow-burst-b.png",
  "wood-splinter-a.png", "wood-splinter-b.png",
  "health-warning-a.png", "health-warning-b.png",
  "impact-decal-a.png", "impact-decal-b.png",
] as const;

const STATIC_MATERIAL_BATCH_FILES = new Set([
  "custom/butcher-stall.glb",
  "custom/cash-register.glb",
  "custom/doghouse.glb",
  "holiday/cabin-wreath.glb",
  "holiday/lantern.glb",
  "campfire-stones.glb",
]);

const ASSET_FILES = [
  ...R8_ZOMBIE_MODELS,
  R13_WORLD_MODELS.cowBrown, R13_WORLD_MODELS.cowStrong,
  ...R13_WORLD_MODELS.pines, ...R13_WORLD_MODELS.rocks,
  R13_WORLD_MODELS.fence, R13_WORLD_MODELS.gate,
  R13_WORLD_MODELS.snowhouse, R13_WORLD_MODELS.snowhouseDoor, R13_WORLD_MODELS.snowhouseWindow,
  "holiday/cabin-wreath.glb",
  "holiday/lantern.glb", "tower/arrow.glb", "campfire-stones.glb",
  "custom/butcher-stall.glb", "custom/cash-register.glb", "custom/doghouse.glb",
  "custom/tower-ballista.glb", "custom/tower-frost.glb", "custom/tower-cannon.glb",
  "custom/weapons/machete.glb", "custom/weapons/axe.glb", "custom/weapons/smg.glb",
  "custom/meat-slice.glb", "custom/coin.glb", "custom/boss-zombie.glb",
  ...Object.values(R10_STAFF_MODELS),
  ...R10_ANONYMOUS_CUSTOMERS.map((entry) => entry.model),
  ...PROTAGONISTS.map((entry) => entry.model),
  ...NAMED_CUSTOMERS.map((entry) => entry.model),
] as const;

const SHOP_POSITION = new Vector3(-8, 0, -4);
const STALL_POSITION = new Vector3(-8, 0, -7.05);
const PASTURE_CENTER = new Vector3(8.5, 0, 3.7);
const PASTURE_2_CENTER = new Vector3(15.5, 0, -7.5);
const TOWER_POSITIONS: Record<TowerId, Vector3> = {
  ballista: new Vector3(COMBAT_POSITIONS.towers.ballista.x, 0, COMBAT_POSITIONS.towers.ballista.z),
  frost: new Vector3(COMBAT_POSITIONS.towers.frost.x, 0, COMBAT_POSITIONS.towers.frost.z),
  cannon: new Vector3(COMBAT_POSITIONS.towers.cannon.x, 0, COMBAT_POSITIONS.towers.cannon.z),
};
const TOWER_ANIMATION_LOD_DISTANCE = 24;

export class StormGame {
  private readonly engine: Engine;
  private readonly scene: Scene;
  private readonly camera: ArcRotateCamera;
  private readonly input: InputController;
  private readonly assets = new Map<string, AssetContainer>();
  private readonly sun: DirectionalLight;
  private readonly skyLight: HemisphericLight;
  private shadows?: ShadowGenerator;
  private glow?: GlowLayer;
  private cinematicPipeline?: DefaultRenderingPipeline;
  private readonly instrumentation: SceneInstrumentation;
  private readonly snowEmitter: TransformNode;
  private readonly shopLight: PointLight;
  private snowParticles?: ParticleSystem;
  private nearSnowParticles?: ParticleSystem;
  private weatherVeil?: Layer;
  private readonly ambientParticles: ParticleSystem[] = [];
  private readonly combatVfxTextures = new Map<string, Texture>();
  private readonly combatVfxMaterials = new Map<string, StandardMaterial>();
  private readonly combatVfx: TransientCombatVfx[] = [];
  private readonly combatVfxPool: Mesh[] = [];
  private readonly damageWarningLayers: Layer[] = [];
  private blobShadowMaterial?: StandardMaterial;
  private player!: Actor;
  private cow!: CowActor;
  private strongCow?: CowActor;
  private customer!: CustomerActor;
  private readonly customerVariants = new Map<NamedCustomerId | AnonymousCustomerVariant, CustomerActor>();
  private readonly towerActors = new Map<TowerId, TowerActor>();
  private readonly staff = new Map<EmployeeId, StaffActor>();
  private weaponModel?: TransformNode;
  private muzzleFlash?: Mesh;
  private readonly zombies: ZombieActor[] = [];
  private readonly drops: MeatDrop[] = [];
  private readonly projectiles: Projectile[] = [];
  private readonly projectilePools = new Map<TowerId, TransformNode[]>();
  private readonly projectileMaterials = new Map<TowerId, PBRMaterial>();
  private readonly zombieTypeMaterials = new Map<ZombieType, PBRMaterial>();
  private readonly carriedVisuals: TransformNode[] = [];
  private readonly stockVisuals: TransformNode[] = [];
  private started = false;
  private zombieAnimationLodTimer = 0;
  private attackCooldown = 0;
  private pendingPlayerAttack?: PendingPlayerAttack;
  private damageEventCount = 0;
  private lastDamageAt = 0;
  private lastEvidenceImpactPosition?: Vector3;
  private lastEvidenceEnemyPosition?: Vector3;
  private vfxEventCount = 0;
  private lastVfxAt = -10;
  private vfxVariant = 0;
  private damageWarningSerial = 0;
  private deduplicatedMaterials = 0;
  private spawnTimer = 0;
  private enemiesToSpawn = 0;
  private customerCooldown = 2;
  private stockedAtCycleStart = false;
  private nightBlend = 0;
  private elapsed = 0;
  private endShown = false;
  private statsTimer = 0;
  private waveStartedStock = 0;
  private waveStockLost = false;
  private wavePlayerKills = 0;
  private waveTowerKills = 0;
  private waveStartTime = 0;
  private readonly patrol = loadPatrol();
  private waveAttractedStart = 0;
  private waveSupply: SupplyId = "standard";
  private baitAimPosition?: Vector3;
  private baitAimRing?: Mesh;
  private towerPreviewRing?: Mesh;
  private selectedPreviewTower: TowerId | null = null;
  private campaignStartTime = performance.now();
  // R23：打擊回饋、連斬、誘餌、信標、遮擋淡化
  private hitStopTimer = 0;
  private readonly combo = createCombo();
  private runBestCombo = 0;
  private waveBestCombo = 0;
  private waveWallDamage = 0;
  private bait?: MeatBait;
  private baitCooldown = 0;
  private baitsThrown = 0;
  private baitScraps = 0;
  private baitedZombies = 0;
  private hitStops = 0;
  private hitFlashes = 0;
  private floaterCount = 0;
  private beacon?: TransformNode;
  private beaconTarget = "none";
  private readonly fadedOccluders = new Set<AbstractMesh>();
  private occlusionTimer = 0;
  private occluderCandidates: AbstractMesh[] = [];
  private occluderCandidatesAt = 0;
  private flashingZombies: ZombieActor[] = [];
  private lastWaveGrade = "";
  private attackCount = 0;
  private uiUpdateTimer = 0;
  private lowFpsSamples = 0;
  private performanceTier = 0;
  private blobShadowsActive = false;
  private blobShadowSource?: Mesh;
  private readonly zombieTypeRingSources = new Map<ZombieType, Mesh>();
  private zombieBrutePlateSource?: Mesh;
  private renderPixelRatio = 1;
  private paused = false;
  private cameraShake = 0;
  private cameraSafeFrame?: CameraSafeFrame;
  private resizeEventCount = 0;
  private resizeRebuildCount = 0;
  private lastTowerAlarmAt = -10;
  private currentWavePlan?: WavePlan;
  private weatherIntensity: WeatherIntensity = "low";
  private readonly testBuild = import.meta.env.DEV || import.meta.env.MODE === "smoke";
  private readonly smokeMode = this.testBuild && new URLSearchParams(window.location.search).has("smoke");
  private readonly showcaseMode = this.testBuild && new URLSearchParams(window.location.search).has("showcase");
  private readonly visualEvidenceMode = this.testBuild && new URLSearchParams(window.location.search).has("visual-evidence");
  private readonly weatherOverride = this.testBuild
    ? parseWeatherIntensity(new URLSearchParams(window.location.search).get("weather"))
    : undefined;

  constructor(
    canvas: HTMLCanvasElement,
    private readonly ui: UiController,
    private readonly state: RuntimeState,
    private readonly settings: PlayerSettings,
    private readonly audio: ProceduralAudio,
  ) {
    this.state.quality = this.detectQuality(this.settings.quality);
    const lowQuality = this.state.quality === "低";
    const devicePixelRatio = Math.max(1, window.devicePixelRatio || 1);
    this.renderPixelRatio = this.smokeMode
      ? 0.5
      : lowQuality
      ? Math.min(1, devicePixelRatio)
      : this.state.quality === "中"
        ? Math.min(1, devicePixelRatio)
        : Math.min(1.25, devicePixelRatio);
    // High quality already owns FXAA and 2x post-process sampling. Avoid a
    // second context-level AA path plus retained framebuffer/stencil buffers;
    // they add cost but no visible benefit to this forward-rendered scene.
    this.engine = new Engine(canvas, false, {
      preserveDrawingBuffer: false,
      stencil: false,
      powerPreference: "high-performance",
    }, false);
    // Hardware scaling is the inverse of the desired pixel ratio in Babylon.
    // Low quality therefore renders at no more than one backing pixel per CSS pixel,
    // even on 3x DPR phones, and can step down further when FPS stays below target.
    this.engine.setHardwareScalingLevel(1 / this.renderPixelRatio);
    this.scene = new Scene(this.engine);
    this.scene.clearColor = lowQuality
      ? new Color4(0.045, 0.095, 0.15, 1)
      : new Color4(0.57, 0.69, 0.74, 1);
    this.scene.fogMode = Scene.FOGMODE_EXP2;
    this.scene.fogDensity = lowQuality ? 0.0045 : 0.012;
    this.scene.fogColor = lowQuality
      ? new Color3(0.065, 0.13, 0.19)
      : new Color3(0.58, 0.68, 0.72);
    this.scene.environmentIntensity = lowQuality ? 0.62 : 0.9;

    this.camera = new ArcRotateCamera("follow-camera", -Math.PI * 0.28, 1.02, 19, new Vector3(0, 1.2, 0), this.scene);
    this.camera.lowerRadiusLimit = 14;
    this.camera.upperRadiusLimit = 30;
    this.camera.minZ = 0.1;
    this.camera.maxZ = 110;
    this.camera.fov = 0.78;
    this.camera.inputs.clear();

    this.skyLight = new HemisphericLight("polar-skylight", new Vector3(0.2, 1, 0.1), this.scene);
    this.skyLight.intensity = lowQuality ? 0.95 : 1.25;
    this.skyLight.diffuse = lowQuality ? new Color3(0.52, 0.68, 0.78) : new Color3(0.78, 0.88, 0.93);
    this.skyLight.groundColor = lowQuality ? new Color3(0.11, 0.16, 0.2) : new Color3(0.2, 0.27, 0.31);
    // R18 A-01：半球光高光歸零——去除全場平面亮片感，讓層次交給主光與燈籠
    this.skyLight.specular = new Color3(0, 0, 0);
    this.sun = new DirectionalLight("low-winter-sun", new Vector3(-0.52, -1, 0.38), this.scene);
    this.sun.position = new Vector3(24, 35, -20);
    this.sun.intensity = lowQuality ? 1.65 : 2.4;
    this.sun.diffuse = new Color3(1, 0.91, 0.79);
    // R18 A-01：主光高光收暖降強——雪地爆白高光收斂、低角度冬陽更有方向感
    this.sun.specular = new Color3(0.66, 0.58, 0.45);
    if (!lowQuality) {
      const shadowSize = this.state.quality === "中" ? 1024 : 2048;
      this.shadows = new ShadowGenerator(shadowSize, this.sun, true);
      this.shadows.usePercentageCloserFiltering = true;
      this.shadows.filteringQuality = ShadowGenerator.QUALITY_MEDIUM;
      this.shadows.bias = 0.002;
      this.shadows.normalBias = 0.03;

      this.glow = new GlowLayer("warm-window-glow", this.scene, { mainTextureFixedSize: 512, blurKernelSize: 48 });
      this.glow.intensity = 0.48;
      this.cinematicPipeline = new DefaultRenderingPipeline("storm-cinematic", true, this.scene, [this.camera]);
      this.cinematicPipeline.fxaaEnabled = true;
      this.cinematicPipeline.bloomEnabled = true;
      this.cinematicPipeline.bloomThreshold = 0.78;
      this.cinematicPipeline.bloomWeight = 0.2;
      this.cinematicPipeline.bloomKernel = 48;
      this.cinematicPipeline.imageProcessingEnabled = true;
      this.cinematicPipeline.imageProcessing.contrast = 1.08;
      this.cinematicPipeline.imageProcessing.exposure = 1.15;
      this.cinematicPipeline.samples = this.state.quality === "高" ? 2 : 1;
    } else {
      // Keep low-quality color grading in the material pass: no FXAA, bloom,
      // glow render target, MSAA, or image-processing post-process is allocated.
      this.scene.imageProcessingConfiguration.contrast = 1.12;
      this.scene.imageProcessingConfiguration.exposure = 1.05;
    }

    this.shopLight = new PointLight("shop-lantern-light", new Vector3(-8, 3.4, -6.1), this.scene);
    this.shopLight.diffuse = new Color3(1, 0.55, 0.25);
    // R18 A-01：燈籠高光同步暖化——近景金屬/雪面反光不再出現冷白點
    this.shopLight.specular = new Color3(0.85, 0.5, 0.24);
    this.shopLight.intensity = 16;
    this.shopLight.range = 13;
    this.snowEmitter = new TransformNode("snow-emitter", this.scene);
    this.instrumentation = new SceneInstrumentation(this.scene);
    this.scene.onAfterRenderObservable.add(() => {
      this.state.currentFps = this.engine.getFps();
      this.state.drawCalls = this.instrumentation.drawCallsCounter.current;
      canvas.dataset.fps = Math.round(this.state.currentFps).toString();
      canvas.dataset.drawCalls = this.state.drawCalls.toString();
      canvas.dataset.activeMeshes = this.scene.getActiveMeshes().length.toString();
      canvas.dataset.quality = this.state.quality;
      canvas.dataset.renderScale = this.renderPixelRatio.toFixed(2);
      canvas.dataset.devicePixelRatio = devicePixelRatio.toFixed(2);
      canvas.dataset.performanceTier = this.performanceTier.toString();
      canvas.dataset.shadowMode = this.blobShadowsActive || !this.shadows ? "blob" : "realtime";
      canvas.dataset.postEffects = this.glow || this.cinematicPipeline ? "on" : "off";
      canvas.dataset.fogDensity = this.scene.fogDensity.toFixed(4);
      const weatherProfile = WEATHER_PROFILES[this.weatherIntensity];
      canvas.dataset.weatherIntensity = this.weatherIntensity;
      canvas.dataset.weatherFarRate = Math.round(this.snowParticles?.emitRate ?? 0).toString();
      canvas.dataset.weatherNearRate = Math.round(this.nearSnowParticles?.emitRate ?? 0).toString();
      canvas.dataset.weatherDensity = this.weatherDensityMultiplier().toFixed(3);
      canvas.dataset.weatherBehavior = weatherBehaviorSignature(weatherProfile);
      canvas.dataset.weatherPost = JSON.stringify({
        contrast: weatherProfile.contrast,
        exposure: weatherProfile.exposure,
        veilAlpha: weatherProfile.veilAlpha,
        vignetteWeight: weatherProfile.vignetteWeight,
        bloomWeight: weatherProfile.bloomWeight,
      });
      canvas.dataset.saveVersion = this.state.version.toString();
      canvas.dataset.debugProtagonist = this.state.protagonistId;
      canvas.dataset.paused = String(this.paused);
      canvas.dataset.waveEvent = this.currentWavePlan?.event ?? "none";
      canvas.dataset.customer = this.customer?.identity ?? "anonymous";
      if (this.player) {
        const meshForward = this.player.meshForwardNode.getDirection(this.player.meshForwardAxis).normalize();
        canvas.dataset.playerX = this.player.root.position.x.toFixed(2);
        canvas.dataset.playerZ = this.player.root.position.z.toFixed(2);
        canvas.dataset.playerMeshForwardX = meshForward.x.toFixed(3);
        canvas.dataset.playerMeshForwardZ = meshForward.z.toFixed(3);
        canvas.dataset.weapon = this.state.weapon;
        canvas.dataset.attackCount = this.attackCount.toString();
        canvas.dataset.attackPhase = this.playerAttackPhase();
        canvas.dataset.damageEvents = this.damageEventCount.toString();
        canvas.dataset.lastDamageAt = this.lastDamageAt.toFixed(3);
        canvas.dataset.vfxAssets = R13_VFX_FILES.length.toString();
        canvas.dataset.vfxEvents = this.vfxEventCount.toString();
        canvas.dataset.lastVfxAt = this.lastVfxAt.toFixed(3);
        canvas.dataset.cowsKilled = this.state.stats.cowsKilled.toString();
        canvas.dataset.playerKills = this.state.stats.playerKills.toString();
        canvas.dataset.activeZombies = this.zombies.filter((zombie) => zombie.alive).length.toString();
        canvas.dataset.enemyAttackPhases = this.zombies.filter((zombie) => zombie.alive).map((zombie) => zombie.attackPhase).join(",");
        canvas.dataset.playerAnimation = this.player.currentAnimation || "none";
        canvas.dataset.playerClips = this.player.animations.map((animation) => animation.name).sort().join(",");
        canvas.dataset.towerAnimations = [...this.towerActors.values()]
          .map((tower) => `${tower.id}:${tower.currentAnimation || "stopped"}`)
          .join(",");
        canvas.dataset.towerAnimationLod = [...this.towerActors.values()]
          .map((tower) => `${tower.id}:${tower.animationLodPaused ? "paused" : "active"}`)
          .join(",");
        if (this.smokeMode || this.showcaseMode) {
          canvas.dataset.staffAnimations = [...this.staff.values()]
            .map((staff) => `${staff.id}:${staff.currentAnimation || "none"}`)
            .join(",");
          canvas.dataset.staffClips = [...this.staff.values()]
            .map((staff) => `${staff.id}:${staff.animations.map((animation) => animation.name).sort().join("|")}`)
            .join(",");
          canvas.dataset.staffMeshForward = [...this.staff.values()]
            .map((staff) => {
              const forward = staff.meshForwardNode.getDirection(staff.meshForwardAxis).normalize();
              return `${staff.id}:${forward.x.toFixed(3)}|${forward.z.toFixed(3)}`;
            })
            .join(",");
        }
      }
    });
    this.input = new InputController(ui.joystick);
    this.bindWorldActions();
    if (this.testBuild) {
      (window as Window & { __stormR15ActiveMeshNames?: () => string[] }).__stormR15ActiveMeshNames = () => {
        const activeMeshes = this.scene.getActiveMeshes();
        return activeMeshes.data.slice(0, activeMeshes.length).map((mesh) => mesh.name).sort();
      };
    }
    if (this.smokeMode) {
      (window as Window & { __stormSelectProtagonist?: (id: ProtagonistId) => void }).__stormSelectProtagonist = (id) => this.selectProtagonist(id);
      (window as Window & { __stormStartWave?: () => void }).__stormStartWave = () => this.startWave();
      (window as Window & { __stormWorldPoint?: (type: WorldPickAction["type"], id: string) => { x: number; y: number } | null }).__stormWorldPoint = (type, id) => this.worldActionScreenPoint(type, id);
      (window as Window & { __stormR19Framing?: () => unknown }).__stormR19Framing = () => this.playerFramingSnapshot();
      (window as Window & { __stormR19ResizeStats?: () => unknown }).__stormR19ResizeStats = () => ({
        events: this.resizeEventCount,
        rebuilds: this.resizeRebuildCount,
      });
      if (this.visualEvidenceMode) {
        (window as Window & { __stormR15EnemyPoint?: () => { x: number; y: number } | null }).__stormR15EnemyPoint = () => this.lastEvidenceEnemyPosition
          ? this.worldPositionScreenPoint(this.lastEvidenceEnemyPosition)
          : this.nearestEnemyScreenPoint();
        (window as Window & { __stormR15ImpactPoint?: () => { x: number; y: number } | null }).__stormR15ImpactPoint = () => this.lastEvidenceImpactPosition
          ? this.worldPositionScreenPoint(this.lastEvidenceImpactPosition)
          : null;
        (window as Window & { __stormR15FreezeFrame?: () => void }).__stormR15FreezeFrame = () => {
          this.paused = true;
        };
      }
    }
    this.createTerrain();
    this.createSnow();
    this.createDistantStorm();

    let resizeTimer: number | undefined;
    window.addEventListener("resize", () => {
      this.resizeEventCount += 1;
      this.cameraSafeFrame = undefined;
      if (resizeTimer !== undefined) window.clearTimeout(resizeTimer);
      // R19（SA-R1-03）：讓 CSS/visual viewport 先穩定，再只重建一次 Babylon
      // render target，避免旋轉時連續 resize 與 layout 同幀尖峰。
      resizeTimer = window.setTimeout(() => {
        resizeTimer = undefined;
        this.engine.resize();
        this.resizeRebuildCount += 1;
        this.cameraSafeFrame = undefined;
      }, 140);
    }, { passive: true });
    window.setInterval(() => this.monitorPerformance(), 2000);
    this.engine.runRenderLoop(() => {
      let dt = Math.min(this.engine.getDeltaTime() / 1000, this.smokeMode ? 0.5 : 0.1);
      // R23 hit-stop：近戰命中幀後短暫凍結模擬與動畫（只在命中時觸發，揮空不停頓）
      if (this.hitStopTimer > 0 && !this.paused) {
        this.hitStopTimer -= dt;
        dt *= 0.06;
        this.scene.animationTimeScale = 0.06;
      } else if (this.scene.animationTimeScale !== 1) {
        this.scene.animationTimeScale = 1;
      }
      if (!this.paused) this.update(dt);
      this.scene.render();
    });
  }

  async initialize(): Promise<void> {
    if (this.showcaseMode) {
      this.state.stallLevel = 4;
      this.state.displayedMeat = 6;
      this.state.towers = { ballista: 1, frost: 1, cannon: 1 };
      this.state.employees = { hunter: 2, cashier: 2, dog: 2 };
    }
    let loaded = 0;
    let nextAsset = 0;
    const fileProgress = new Map<string, number>();
    const loadAsset = async (file: (typeof ASSET_FILES)[number]): Promise<void> => {
      const container = await LoadAssetContainerAsync(`${import.meta.env.BASE_URL}models/${file}`, this.scene, {
        onProgress: (event) => {
          fileProgress.set(file, event.lengthComputable && event.total > 0 ? event.loaded / event.total : 0.35);
          const aggregate = [...fileProgress.values()].reduce((sum, value) => sum + value, 0) / ASSET_FILES.length;
          this.ui.setLoading(Math.min(0.82, aggregate * 0.82), `串流北境資產 · ${loaded} / ${ASSET_FILES.length}`);
        },
      });
      this.assets.set(file, container);
      loaded += 1;
      fileProgress.set(file, 1);
      this.ui.setLoading(loaded / ASSET_FILES.length * 0.82, `載入北境資產 · ${loaded} / ${ASSET_FILES.length}`);
    };
    const loadWorker = async (): Promise<void> => {
      while (nextAsset < ASSET_FILES.length) {
        const file = ASSET_FILES[nextAsset];
        nextAsset += 1;
        await loadAsset(file);
      }
    };
    const loadConcurrency = this.state.quality === "低" ? 3 : 5;
    await Promise.all([
      ...Array.from({ length: loadConcurrency }, () => loadWorker()),
      this.loadCombatVfx(),
    ]);
    this.deduplicateAssetMaterials();
    this.ui.setLoading(0.86, "佈置牧場與肉舖…");
    this.buildEnvironment();
    this.createActors();
    this.createTowers();
    this.createWeaponModel();
    this.syncUnlockedContent();
    this.createMeatDisplays();
    this.freezeStaticScene();
    this.ui.update(this.state);
    this.processQuests();
    this.ui.setLoading(0.96, "校準暴風光影…");
    await new Promise<void>((resolve) => window.setTimeout(resolve, 250));
  }

  start(): void {
    if (this.started) return;
    this.started = true;
    this.ui.enterGame();
    const protagonist = PROTAGONISTS.find((entry) => entry.id === this.state.protagonistId)!;
    this.ui.toast(`「${protagonist.openingLine}」`, "ice");
  }

  setPaused(paused: boolean): void {
    if (this.paused === paused) return;
    this.paused = paused;
    if (paused) { this.releaseBait(false); this.previewTower(null); }
    this.input.setEnabled(!paused);
    this.scene.animationTimeScale = paused ? 0 : 1;
    const canvas = this.engine.getRenderingCanvas();
    if (canvas) canvas.dataset.paused = String(paused);
    this.ui.update(this.state);
  }

  applySettings(settings: PlayerSettings): void {
    Object.assign(this.settings, settings);
    if (!this.settings.screenShake) this.cameraShake = 0;
    const nextQuality = this.detectQuality(this.settings.quality);
    if (nextQuality === this.state.quality) return;
    this.state.quality = nextQuality;
    this.performanceTier = 0;
    this.lowFpsSamples = 0;
    this.applyQualityLevel(nextQuality);
    this.ui.update(this.state);
    this.ui.toast(`畫質已切換為${nextQuality}檔`, "ice");
  }

  selectProtagonist(id: ProtagonistId): void {
    if ((!this.state.requiresProtagonistSelection && !this.smokeMode) || !PROTAGONISTS.some((entry) => entry.id === id)) return;
    this.state.protagonistId = id;
    this.state.requiresProtagonistSelection = false;
    if (this.player) this.replacePlayerModel();
    saveState(this.state);
    this.ui.update(this.state);
  }

  startAttack(): void { this.input.startAttack(); }
  stopAttack(): void { this.input.stopAttack(); }
  startWave(): void {
    this.ui.hideWorldAction();
    this.input.queueWave();
  }
  cycleWeapon(): void {
    const unlocked = WEAPONS.map((weapon) => weapon.id).filter((id) => this.state.weapons[id]);
    if (unlocked.length <= 1) {
      this.ui.toast("尚未解鎖第二把武器。", "ice");
      return;
    }
    const next = unlocked[(unlocked.indexOf(this.state.weapon) + 1) % unlocked.length];
    this.equipWeapon(next, true);
  }

  shopAction(category: "weapon" | "employee" | "pasture", id: string): void {
    if (category === "weapon") this.buyWeapon(id as WeaponId);
    else if (category === "employee") this.hireEmployee(id as EmployeeId);
    else if (id === "pasture2") this.unlockPasture2();
  }

  towerAction(id: TowerId): void { this.buyOrUpgradeTower(id); }

  requestBait(): void { this.input.queueBait(); }

  chooseSupply(id: SupplyId): void {
    if (this.state.waveActive || !selectSupply(this.patrol, id)) return;
    savePatrol(this.patrol);
    this.ui.updatePatrol(this.patrol, false, this.state.wave + 1);
  }

  previewTower(id: TowerId | null): void {
    this.towerPreviewRing?.dispose(false, true);
    this.towerPreviewRing = undefined;
    this.selectedPreviewTower = id;
    if (!id || !this.started || this.state.waveActive) return;
    const stats = towerCombatStats(id, Math.min(3, this.state.towers[id] + 1));
    this.towerPreviewRing = this.createWorldRing("tower-range-preview", TOWER_POSITIONS[id], stats.range * 2, new Color3(0.95, 0.72, 0.23));
    this.towerPreviewRing.isPickable = false;
  }

  aimBait(dx: number, dy: number, active: boolean): void {
    if (!active || !this.started || this.paused || this.endShown || !this.state.waveActive || this.baitCooldown > 0) { this.releaseBait(false); return; }
    const drag = baitDrag(dx, dy);
    const forward = this.player.meshForwardNode.getDirection(this.player.meshForwardAxis);
    forward.y = 0;
    if (forward.lengthSquared() < 0.01) forward.set(0, 0, 1);
    forward.normalize();
    if (drag.aimed) {
      const cameraForward = this.camera.getForwardRay().direction;
      cameraForward.y = 0;
      cameraForward.normalize();
      const right = this.camera.getDirection(Vector3.Right());
      right.y = 0;
      right.normalize();
      forward.copyFrom(right.scale(drag.x).add(cameraForward.scale(-drag.y)).normalize());
    }
    const distance = drag.aimed ? 2.4 + drag.power * 5.6 : BAIT_RULES.throwDistance;
    const position = this.player.root.position.add(forward.scale(distance));
    position.x = Math.max(-24, Math.min(24, position.x));
    position.z = Math.max(-20, Math.min(20, position.z));
    position.y = this.heightAt(position.x, position.z);
    this.baitAimPosition = position;
    this.ui.setBaitAimPoint(this.worldPositionScreenPoint(position));
    if (!this.baitAimRing) {
      this.baitAimRing = this.createWorldRing("bait-aim-preview", position, 2, new Color3(1, 0.72, 0.25));
      this.baitAimRing.isPickable = false;
    }
    this.baitAimRing.position.copyFrom(position.add(new Vector3(0, 0.08, 0)));
  }

  releaseBait(commit: boolean): void {
    const target = this.baitAimPosition?.clone();
    this.baitAimPosition = undefined;
    this.baitAimRing?.dispose(false, true);
    this.baitAimRing = undefined;
    this.ui.setBaitAimPoint(null);
    if (commit && target && !this.paused && !this.endShown) this.throwBait(target);
  }

  private bindWorldActions(): void {
    this.scene.onPointerObservable.add((pointerInfo) => {
      if (pointerInfo.type !== PointerEventTypes.POINTERPICK || !this.started || this.endShown) return;
      const action = this.worldActionForMesh(pointerInfo.pickInfo?.pickedMesh ?? null);
      const event = pointerInfo.event;
      if (!action) {
        this.ui.hideWorldAction();
        return;
      }
      this.ui.showWorldAction({
        ...action,
        x: event.clientX,
        y: event.clientY,
      });
    });
  }

  private tagWorldAction(root: TransformNode | AbstractMesh, action: WorldPickAction): void {
    root.metadata = { ...(root.metadata as StormMetadata | null ?? {}), stormAction: action } satisfies StormMetadata;
    if ("isPickable" in root) root.isPickable = true;
    for (const mesh of root.getChildMeshes(false)) {
      mesh.isPickable = true;
      mesh.metadata = { ...(mesh.metadata as StormMetadata | null ?? {}), stormAction: action } satisfies StormMetadata;
    }
  }

  private worldActionForMesh(mesh: AbstractMesh | null): WorldPickAction | null {
    let current: TransformNode | AbstractMesh | null = mesh;
    while (current) {
      const action = (current.metadata as StormMetadata | null)?.stormAction;
      if (action) return action;
      current = current.parent as TransformNode | AbstractMesh | null;
    }
    return null;
  }

  private worldActionScreenPoint(type: WorldPickAction["type"], id: string): { x: number; y: number } | null {
    let position: Vector3 | null = null;
    if (type === "tower" && (id === "ballista" || id === "frost" || id === "cannon")) {
      position = TOWER_POSITIONS[id].clone();
      position.y = this.heightAt(position.x, position.z) + 0.7;
    } else if (type === "pasture" && id === "pasture2") {
      position = new Vector3(5.2, this.heightAt(5.2, -3.2) + 0.7, -3.2);
    } else if (type === "employee" && (id === "hunter" || id === "cashier" || id === "dog")) {
      const actor = this.staff.get(id);
      if (actor) position = actor.root.position.add(new Vector3(0, 1.2, 0));
      else if (id === "cashier") position = new Vector3(-5.65, this.heightAt(-5.65, -6.3) + 1.2, -6.3);
      else if (id === "dog") position = new Vector3(-5.15, this.heightAt(-5.15, -8.45) + 0.9, -8.45);
    }
    if (!position) return null;
    const canvas = this.engine.getRenderingCanvas();
    if (!canvas) return null;
    const viewport = this.camera.viewport.toGlobal(this.engine.getRenderWidth(), this.engine.getRenderHeight());
    const projected = Vector3.Project(position, Matrix.Identity(), this.scene.getTransformMatrix(), viewport);
    const bounds = canvas.getBoundingClientRect();
    return {
      x: bounds.left + projected.x * bounds.width / this.engine.getRenderWidth(),
      y: bounds.top + projected.y * bounds.height / this.engine.getRenderHeight(),
    };
  }

  private nearestEnemyScreenPoint(): { x: number; y: number } | null {
    const enemy = this.zombies
      .filter((zombie) => zombie.alive)
      .sort((left, right) => Vector3.DistanceSquared(left.root.position, this.player.root.position)
        - Vector3.DistanceSquared(right.root.position, this.player.root.position))[0];
    if (!enemy) return null;
    return this.worldPositionScreenPoint(enemy.root.position.add(new Vector3(0, 1.15, 0)));
  }

  private worldPositionScreenPoint(position: Vector3): { x: number; y: number } | null {
    const canvas = this.engine.getRenderingCanvas();
    if (!canvas) return null;
    const viewport = this.camera.viewport.toGlobal(this.engine.getRenderWidth(), this.engine.getRenderHeight());
    const projected = Vector3.Project(position, Matrix.Identity(), this.scene.getTransformMatrix(), viewport);
    const bounds = canvas.getBoundingClientRect();
    return {
      x: bounds.left + projected.x * bounds.width / this.engine.getRenderWidth(),
      y: bounds.top + projected.y * bounds.height / this.engine.getRenderHeight(),
    };
  }

  private createTerrain(): void {
    const ground = MeshBuilder.CreateGround("wind-carved-snow", { width: 56, height: 48, subdivisions: 72, updatable: true }, this.scene);
    const positions = ground.getVerticesData(VertexBuffer.PositionKind)!;
    const indices = ground.getIndices()!;
    for (let index = 0; index < positions.length; index += 3) {
      const x = positions[index];
      const z = positions[index + 2];
      positions[index + 1] = this.heightAt(x, z);
    }
    const normals = new Float32Array(positions.length);
    VertexData.ComputeNormals(positions, indices, normals);
    ground.updateVerticesData(VertexBuffer.PositionKind, positions);
    ground.updateVerticesData(VertexBuffer.NormalKind, normals);
    ground.receiveShadows = Boolean(this.shadows);

    const snow = new PBRMaterial("powder-snow", this.scene);
    snow.albedoColor = new Color3(0.78, 0.87, 0.89);
    snow.roughness = 0.93;
    snow.metallic = 0;
    snow.environmentIntensity = 0.7;
    const snowTexture = this.createSnowTexture();
    snowTexture.uScale = 10;
    snowTexture.vScale = 9;
    snowTexture.wrapU = Texture.WRAP_ADDRESSMODE;
    snowTexture.wrapV = Texture.WRAP_ADDRESSMODE;
    snow.albedoTexture = snowTexture;
    snow.bumpTexture = snowTexture;
    snow.bumpTexture.level = 0.16;
    ground.material = snow;

    const underSnow = MeshBuilder.CreateCylinder("world-skirt", { diameter: 59, height: 5, tessellation: 64 }, this.scene);
    underSnow.position.y = -2.5;
    const skirtMaterial = new PBRMaterial("packed-snow-edge", this.scene);
    skirtMaterial.albedoColor = new Color3(0.29, 0.39, 0.43);
    skirtMaterial.roughness = 1;
    underSnow.material = skirtMaterial;
    underSnow.receiveShadows = Boolean(this.shadows);
  }

  private createSnowTexture(): DynamicTexture {
    const textureSize = this.state.quality === "低" ? 256 : this.state.quality === "中" ? 384 : 512;
    const texture = new DynamicTexture(
      "wind-swept-snow-texture",
      textureSize,
      this.scene,
      false,
      Texture.TRILINEAR_SAMPLINGMODE,
      Constants.TEXTUREFORMAT_RGBA,
    );
    const context = texture.getContext() as unknown as CanvasRenderingContext2D;
    const image = context.createImageData(textureSize, textureSize);
    let seed = 1917;
    const random = (): number => {
      seed = (seed * 1664525 + 1013904223) >>> 0;
      return seed / 4294967296;
    };
    for (let pixel = 0; pixel < image.data.length; pixel += 4) {
      const x = (pixel / 4) % textureSize;
      const y = Math.floor(pixel / 4 / textureSize);
      const dune = Math.sin((x + y * 0.55) * 0.055) * 7;
      const value = Math.max(165, Math.min(244, 214 + dune + (random() - 0.5) * 18));
      image.data[pixel] = value * 0.92;
      image.data[pixel + 1] = value * 0.98;
      image.data[pixel + 2] = value;
      image.data[pixel + 3] = 255;
    }
    context.putImageData(image, 0, 0);
    context.globalAlpha = this.state.quality === "低" ? 0.14 : 0.2;
    context.strokeStyle = "#ffffff";
    for (let line = 0; line < Math.round(textureSize / 15); line += 1) {
      const y = random() * textureSize;
      context.beginPath();
      context.moveTo(-20, y);
      context.bezierCurveTo(textureSize * 0.27, y - textureSize * 0.035, textureSize * 0.66, y + textureSize * 0.043, textureSize + 28, y - textureSize * 0.016);
      context.stroke();
    }
    if (this.state.quality !== "低") {
      context.globalAlpha = 0.12;
      context.lineWidth = Math.max(1, textureSize / 220);
      context.strokeStyle = "#6f9dac";
      for (let groove = 0; groove < Math.round(textureSize / 48); groove += 1) {
        const y = random() * textureSize;
        context.beginPath();
        context.moveTo(-30, y);
        context.bezierCurveTo(textureSize * 0.3, y + textureSize * 0.055, textureSize * 0.72, y - textureSize * 0.04, textureSize + 35, y + textureSize * 0.018);
        context.stroke();
      }
      context.globalAlpha = 0.16;
      context.lineWidth = 1;
      context.strokeStyle = "#edfaff";
      for (let crystal = 0; crystal < Math.round(textureSize / 5); crystal += 1) {
        const x = random() * textureSize;
        const y = random() * textureSize;
        context.beginPath();
        context.moveTo(x, y);
        context.lineTo(x + 2 + random() * 4, y - 1 - random() * 3);
        context.stroke();
      }
    }
    texture.update(false);
    return texture;
  }

  private createSnow(): void {
    const flake = new DynamicTexture("soft-snowflake", 32, this.scene, false);
    const context = flake.getContext();
    const gradient = context.createRadialGradient(16, 16, 1, 16, 16, 15);
    gradient.addColorStop(0, "rgba(255,255,255,1)");
    gradient.addColorStop(0.28, "rgba(235,251,255,.9)");
    gradient.addColorStop(1, "rgba(220,245,255,0)");
    context.fillStyle = gradient;
    context.fillRect(0, 0, 32, 32);
    flake.hasAlpha = true;
    flake.update(false);

    const veilTexture = new DynamicTexture("storm-weather-veil-texture", 256, this.scene, false);
    const veilContext = veilTexture.getContext() as unknown as CanvasRenderingContext2D;
    const veilGradient = veilContext.createRadialGradient(128, 128, 46, 128, 128, 184);
    veilGradient.addColorStop(0, "rgba(4,20,31,0)");
    veilGradient.addColorStop(0.58, "rgba(5,24,36,0.04)");
    veilGradient.addColorStop(1, "rgba(3,18,30,0.94)");
    veilContext.fillStyle = veilGradient;
    veilContext.fillRect(0, 0, 256, 256);
    veilTexture.hasAlpha = true;
    veilTexture.update(false);
    this.weatherVeil = new Layer("storm-weather-veil", null, this.scene, false, new Color4(1, 1, 1, 0));
    this.weatherVeil.texture = veilTexture;
    this.weatherVeil.alphaTest = false;

    // Capacity stays fixed across quality levels so switching quality changes
    // density only; wind motion, lifetime, size and intensity behavior remain
    // the same R15 weather profile.
    const snow = new ParticleSystem("blizzard-snow-far", 1200, this.scene);
    this.snowParticles = snow;
    snow.particleTexture = flake;
    snow.emitter = this.snowEmitter.position;
    snow.minEmitBox = new Vector3(-20, 0, -16);
    snow.maxEmitBox = new Vector3(20, 9, 16);
    snow.blendMode = ParticleSystem.BLENDMODE_STANDARD;
    snow.minAngularSpeed = -2;
    snow.maxAngularSpeed = 2;

    const nearSnow = new ParticleSystem("blizzard-snow-near", 320, this.scene);
    this.nearSnowParticles = nearSnow;
    nearSnow.particleTexture = flake;
    nearSnow.emitter = this.snowEmitter.position;
    nearSnow.minEmitBox = new Vector3(-14, -5, -10);
    nearSnow.maxEmitBox = new Vector3(14, 6, 10);
    nearSnow.blendMode = ParticleSystem.BLENDMODE_STANDARD;
    nearSnow.minAngularSpeed = -1.2;
    nearSnow.maxAngularSpeed = 1.2;
    this.applyWeatherVisualProfile(true);
    snow.start();
    nearSnow.start();
  }

  private weatherDensityMultiplier(): number {
    const qualityDensity = WEATHER_QUALITY_DENSITY[this.state.quality];
    const adaptiveDensity = WEATHER_ADAPTIVE_DENSITY[String(Math.min(2, this.performanceTier)) as "0" | "1" | "2"];
    return qualityDensity * adaptiveDensity;
  }

  private applyParticleWeatherProfile(particles: ParticleSystem, profile: WeatherProfile, near: boolean): void {
    particles.color1 = new Color4(...profile.color1);
    particles.color2 = new Color4(...profile.color2);
    particles.minSize = near ? profile.nearMinSize : profile.minSize;
    particles.maxSize = near ? profile.nearMaxSize : profile.maxSize;
    particles.minLifeTime = profile.minLifeTime;
    particles.maxLifeTime = profile.maxLifeTime;
    particles.gravity = new Vector3(...profile.gravity);
    particles.direction1 = new Vector3(...profile.direction1);
    particles.direction2 = new Vector3(...profile.direction2);
  }

  private applyWeatherVisualProfile(force = false): void {
    const nextIntensity = this.weatherOverride
      ?? productionWeatherIntensity(this.state.waveActive, this.currentWavePlan?.event);
    if (!force && nextIntensity === this.weatherIntensity) return;
    this.weatherIntensity = nextIntensity;
    const profile = WEATHER_PROFILES[nextIntensity];
    const density = this.weatherDensityMultiplier();
    if (this.snowParticles) {
      this.applyParticleWeatherProfile(this.snowParticles, profile, false);
      this.snowParticles.emitRate = Math.round(profile.farRate * density);
    }
    if (this.nearSnowParticles) {
      this.applyParticleWeatherProfile(this.nearSnowParticles, profile, true);
      this.nearSnowParticles.emitRate = Math.round(profile.nearRate * density);
    }
    if (this.weatherVeil) this.weatherVeil.color.a = profile.veilAlpha;
    this.applyWeatherPostProcessing(profile);
  }

  private applyWeatherPostProcessing(profile: WeatherProfile): void {
    this.scene.imageProcessingConfiguration.contrast = profile.contrast;
    this.scene.imageProcessingConfiguration.exposure = profile.exposure;
    if (!this.cinematicPipeline) return;
    this.cinematicPipeline.bloomWeight = profile.bloomWeight;
    this.cinematicPipeline.imageProcessing.contrast = profile.contrast;
    this.cinematicPipeline.imageProcessing.exposure = profile.exposure;
    this.cinematicPipeline.imageProcessing.vignetteEnabled = true;
    this.cinematicPipeline.imageProcessing.vignetteWeight = profile.vignetteWeight;
    this.cinematicPipeline.imageProcessing.vignetteStretch = 0.18;
    this.cinematicPipeline.imageProcessing.vignetteColor = new Color4(0.015, 0.055, 0.09, 1);
  }

  private createDistantStorm(): void {
    const material = new StandardMaterial("mountain-silhouette-material", this.scene);
    material.diffuseColor = new Color3(0.18, 0.27, 0.32);
    material.specularColor = Color3.Black();
    const source = MeshBuilder.CreateCylinder("distant-peak-source", { diameterTop: 0, diameterBottom: 10, height: 9, tessellation: 5 }, this.scene);
    source.material = material;
    for (let index = 0; index < 14; index += 1) {
      const mountain = index === 0 ? source : source.createInstance(`distant-peak-${index}`);
      const angle = index / 14 * Math.PI * 2;
      mountain.position.set(Math.sin(angle) * 39, 1.2, Math.cos(angle) * 34);
      mountain.rotation.y = angle * 1.7;
      const diameterScale = (10 + (index % 4) * 3) / 10;
      mountain.scaling.set(1.4 * diameterScale, (9 + (index % 3) * 4) / 9, diameterScale);
    }
  }

  private async loadCombatVfx(): Promise<void> {
    await Promise.all(R13_VFX_FILES.map((file) => new Promise<void>((resolve, reject) => {
      const texture = new Texture(
        `${import.meta.env.BASE_URL}images/vfx/r13/${file}`,
        this.scene,
        false,
        false,
        Texture.TRILINEAR_SAMPLINGMODE,
        () => resolve(),
        (message, exception) => reject(new Error(`R13 VFX texture failed: ${file} (${message ?? exception ?? "unknown"})`)),
      );
      texture.name = `R13 ${file}`;
      texture.hasAlpha = true;
      this.combatVfxTextures.set(file, texture);
    })));
    for (const file of ["health-warning-a.png", "health-warning-b.png"] as const) {
      const layer = new Layer(`R13 ${file}`, null, this.scene, false, new Color4(1, 1, 1, 0.7));
      layer.texture = this.combatVfxTextures.get(file)!;
      layer.alphaTest = false;
      layer.isEnabled = false;
      this.damageWarningLayers.push(layer);
    }
  }

  private combatVfxMaterial(file: string): StandardMaterial {
    const existing = this.combatVfxMaterials.get(file);
    if (existing) return existing;
    const texture = this.combatVfxTextures.get(file)!;
    const material = new StandardMaterial(`R13 VFX ${file}`, this.scene);
    material.diffuseTexture = texture;
    material.opacityTexture = texture;
    material.emissiveTexture = texture;
    material.useAlphaFromDiffuseTexture = true;
    material.diffuseColor = Color3.White();
    material.emissiveColor = Color3.White();
    material.specularColor = Color3.Black();
    material.backFaceCulling = false;
    material.disableLighting = true;
    if (/^(snow-burst|wood-splinter)-/u.test(file)) {
      material.disableDepthWrite = true;
      material.depthFunction = Constants.ALWAYS;
    }
    material.freeze();
    this.combatVfxMaterials.set(file, material);
    return material;
  }

  private spawnBillboardVfx(file: string, position: Vector3, size: number, duration: number): void {
    const mesh = this.acquireCombatVfxMesh(`R13-${file}-${this.vfxEventCount}`);
    mesh.position.set(position.x, this.heightAt(position.x, position.z) + size * 0.32, position.z);
    mesh.rotation.set(0, 0, 0);
    mesh.billboardMode = Mesh.BILLBOARDMODE_ALL;
    mesh.material = this.combatVfxMaterial(file);
    mesh.visibility = 0.96;
    mesh.scaling.setAll(size * 0.62);
    this.combatVfx.push({ mesh, age: 0, duration, startScale: size * 0.62, endScale: size * 1.10 });
  }

  private spawnGroundDecal(position: Vector3): void {
    const oldestDecal = this.combatVfx.findIndex((vfx) => vfx.duration > 1);
    const decalCount = this.combatVfx.reduce((count, vfx) => count + (vfx.duration > 1 ? 1 : 0), 0);
    const file = `impact-decal-${this.vfxVariant % 2 === 0 ? "a" : "b"}.png`;
    const recycled = decalCount >= 6 && oldestDecal >= 0 ? this.combatVfx.splice(oldestDecal, 1)[0] : undefined;
    const mesh = recycled?.mesh ?? this.acquireCombatVfxMesh(`R13-${file}-${this.vfxEventCount}`);
    mesh.name = `R13-${file}-${this.vfxEventCount}`;
    mesh.position.set(position.x, this.heightAt(position.x, position.z) + 0.045, position.z);
    mesh.billboardMode = Mesh.BILLBOARDMODE_NONE;
    mesh.rotation.x = Math.PI / 2;
    mesh.rotation.y = this.vfxVariant * 1.618;
    mesh.rotation.z = 0;
    mesh.material = this.combatVfxMaterial(file);
    mesh.visibility = 0.84;
    mesh.scaling.setAll(2.55 * 0.72);
    this.combatVfx.push({ mesh, age: 0, duration: 6.5, startScale: 2.55 * 0.72, endScale: 2.55 });
  }

  private acquireCombatVfxMesh(name: string): Mesh {
    const mesh = this.combatVfxPool.pop() ?? MeshBuilder.CreatePlane("R13-vfx-unit-quad", { size: 1, sideOrientation: Mesh.DOUBLESIDE }, this.scene);
    mesh.name = name;
    mesh.isPickable = false;
    mesh.setEnabled(true);
    return mesh;
  }

  private triggerGroundImpactVfx(position: Vector3): void {
    // SMG applies three damage packets on one impact frame; keep one authored
    // visual hit instead of stacking three opaque billboards.
    if (this.elapsed - this.lastVfxAt < 0.055) return;
    const file = `snow-burst-${this.vfxVariant % 2 === 0 ? "a" : "b"}.png`;
    this.vfxVariant += 1;
    this.vfxEventCount += 1;
    this.lastVfxAt = this.elapsed;
    if (this.visualEvidenceMode) {
      this.lastEvidenceImpactPosition = new Vector3(position.x, this.heightAt(position.x, position.z) + 2.8 * 0.32, position.z);
    }
    this.spawnBillboardVfx(file, position, 2.8, 0.34);
    this.spawnGroundDecal(position);
  }

  private triggerBarrierHitVfx(position: Vector3, health: number): void {
    const file = `wood-splinter-${this.vfxVariant % 2 === 0 ? "a" : "b"}.png`;
    this.vfxVariant += 1;
    this.vfxEventCount += 1;
    this.lastVfxAt = this.elapsed;
    this.spawnBillboardVfx(file, position.add(new Vector3(0, 0.55, 0)), health <= 35 ? 4.4 : 3.7, 0.42);
    this.spawnGroundDecal(position);
    const layerIndex = this.vfxVariant % this.damageWarningLayers.length;
    const serial = ++this.damageWarningSerial;
    for (const [index, layer] of this.damageWarningLayers.entries()) {
      layer.isEnabled = index === layerIndex;
      layer.color.a = health <= 35 ? 0.82 : 0.58;
    }
    window.setTimeout(() => {
      if (serial === this.damageWarningSerial) this.damageWarningLayers[layerIndex].isEnabled = false;
    }, health <= 35 ? 520 : 280);
  }

  private updateCombatVfx(dt: number): void {
    for (let index = this.combatVfx.length - 1; index >= 0; index -= 1) {
      const vfx = this.combatVfx[index];
      vfx.age += dt;
      const progress = Math.min(1, vfx.age / vfx.duration);
      const eased = 1 - (1 - progress) * (1 - progress);
      vfx.mesh.scaling.setAll(vfx.startScale + (vfx.endScale - vfx.startScale) * eased);
      if (progress > 0.72) vfx.mesh.visibility = Math.max(0, (1 - progress) / 0.28);
      if (progress < 1) continue;
      vfx.mesh.setEnabled(false);
      if (this.combatVfxPool.length < 16) this.combatVfxPool.push(vfx.mesh);
      else vfx.mesh.dispose(false, false);
      this.combatVfx.splice(index, 1);
    }
  }

  private buildEnvironment(): void {
    this.buildShop();
    this.buildPasture();
    this.buildForest();
    this.buildWayfinding();
  }

  private buildShop(): void {
    const shop = new TransformNode("northwind-butcher-shop", this.scene);
    shop.position.copyFrom(SHOP_POSITION);
    shop.position.y = this.heightAt(shop.position.x, shop.position.z);

    const place = (file: string, local: Vector3, rotationY: number, scale = 1.35): TransformNode => {
      const model = this.instantiateStatic(file, `shop-${file}-${local.x}-${local.z}`);
      model.parent = shop;
      model.position.copyFrom(local);
      model.rotation.y = rotationY;
      model.scaling.setAll(scale);
      return model;
    };

    place(R13_WORLD_MODELS.snowhouse, Vector3.Zero(), 0);
    place(R13_WORLD_MODELS.snowhouseDoor, new Vector3(0, 0, -2.76), 0);
    place(R13_WORLD_MODELS.snowhouseWindow, new Vector3(-1.55, 0.52, 2.74), Math.PI, 1.16);
    place(R13_WORLD_MODELS.snowhouseWindow, new Vector3(3.08, 0.52, 0.25), -Math.PI / 2, 1.16);
    place("holiday/cabin-wreath.glb", new Vector3(0, 1.55, 2.84), Math.PI, 1.45);
    place("holiday/lantern.glb", new Vector3(-1.15, 2.30, -2.98), Math.PI, 1.08);
    place("holiday/lantern.glb", new Vector3(1.15, 2.30, -2.98), Math.PI, 1.08);
    const stall = place("custom/butcher-stall.glb", new Vector3(0, 0, -3.05), 0, 1);
    this.tagWorldAction(stall, { type: "employee", id: "cashier" });

    const checkout = this.instantiateStatic("custom/cash-register.glb", "butcher-checkout");
    checkout.position.set(-5.65, this.heightAt(-5.65, -6.3), -6.3);
    checkout.rotation.y = -Math.PI / 2;
    checkout.scaling.setAll(0.82);
    this.tagWorldAction(checkout, { type: "employee", id: "cashier" });

    const doghouse = this.instantiateStatic("custom/doghouse.glb", "shepherd-doghouse");
    doghouse.position.set(-5.15, this.heightAt(-5.15, -8.45), -8.45);
    doghouse.rotation.y = -0.28;
    doghouse.scaling.setAll(0.84);
    this.tagWorldAction(doghouse, { type: "employee", id: "dog" });

    for (let index = 0; index < 3; index += 1) {
      const coin = this.instantiateStatic("custom/coin.glb", `checkout-coin-${index}`);
      coin.position.set(-5.48 + index * 0.08, checkout.position.y + 1.7 + index * 0.025, -6.18 + index * 0.04);
      coin.rotation.set(Math.PI / 2, index * 0.35, 0);
      coin.scaling.setAll(0.2);
    }

    const signScale = this.state.quality === "低" ? 0.5 : this.state.quality === "中" ? 0.75 : 1;
    const signTexture = new DynamicTexture("butcher-sign-texture", { width: Math.round(512 * signScale), height: Math.round(192 * signScale) }, this.scene, true);
    const context = signTexture.getContext() as unknown as CanvasRenderingContext2D;
    context.scale(signScale, signScale);
    context.fillStyle = "#3a231b";
    context.fillRect(0, 0, 512, 192);
    context.strokeStyle = "#c49455";
    context.lineWidth = 12;
    context.strokeRect(9, 9, 494, 174);
    context.fillStyle = "#f4d89a";
    context.font = "900 58px serif";
    context.textAlign = "center";
    context.fillText("北 境 肉 舖", 256, 88);
    context.fillStyle = "#c8a66f";
    context.font = "700 24px sans-serif";
    context.fillText("THE LAST BUTCHER", 256, 137);
    signTexture.update();
    const signMaterial = new StandardMaterial("butcher-sign-material", this.scene);
    signMaterial.diffuseTexture = signTexture;
    signMaterial.emissiveColor = new Color3(0.35, 0.17, 0.07);
    signMaterial.backFaceCulling = false;
    const sign = MeshBuilder.CreatePlane("butcher-shop-sign", { width: 3.7, height: 1.3 }, this.scene);
    sign.position.set(-8, 3.05 + shop.position.y, -5.76);
    sign.rotation.y = Math.PI;
    sign.material = signMaterial;

    const warmWindow = new PBRMaterial("warm-window-material", this.scene);
    warmWindow.albedoColor = new Color3(0.86, 0.38, 0.08);
    warmWindow.emissiveColor = new Color3(1, 0.28, 0.03);
    warmWindow.emissiveIntensity = 2.2;
    warmWindow.roughness = 0.42;
    for (const x of [-9.75, -6.25]) {
      const glowPane = MeshBuilder.CreatePlane(`warm-window-${x}`, { width: 1.35, height: 1.35 }, this.scene);
      glowPane.position.set(x, 1.5 + shop.position.y, -5.74);
      glowPane.rotation.y = Math.PI;
      glowPane.material = warmWindow;
    }

    this.createCampfire(new Vector3(-11.8, 0, 1.8));
  }

  private buildPasture(): void {
    const fencePositions: Array<[number, number, number]> = [];
    for (let x = 3.1; x <= 14.9; x += 2) {
      fencePositions.push([x, -3.2, 0], [x, 10.3, 0]);
    }
    for (let z = -2.2; z <= 9.2; z += 2) {
      fencePositions.push([2.1, z, Math.PI / 2], [15.9, z, Math.PI / 2]);
    }
    for (const [x, z, rotation] of fencePositions) {
      const fence = this.instantiateStatic(R13_WORLD_MODELS.fence, `pasture-fence-${x}-${z}`);
      fence.position.set(x, this.heightAt(x, z), z);
      fence.rotation.y = rotation;
      fence.scaling.setAll(1.55);
      this.tagWorldAction(fence, { type: "pasture", id: "pasture2" });
    }
    const gate = this.instantiateStatic(R13_WORLD_MODELS.gate, "pasture-gate");
    gate.position.set(5.2, this.heightAt(5.2, -3.2), -3.2);
    gate.scaling.setAll(1.55);
    this.tagWorldAction(gate, { type: "pasture", id: "pasture2" });
    const hayRing = this.createWorldRing("pasture-marker", PASTURE_CENTER, 3.3, new Color3(0.2, 0.75, 0.82));
    hayRing.visibility = 0.42;
    this.tagWorldAction(hayRing, { type: "pasture", id: "pasture2" });
  }

  private buildForest(): void {
    let seed = 73421;
    const random = (): number => {
      seed = (seed * 16807) % 2147483647;
      return (seed - 1) / 2147483646;
    };
    const positions: Vector2[] = [];
    for (let index = 0; index < 42; index += 1) {
      const angle = random() * Math.PI * 2;
      const radius = 18 + random() * 8;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius * 0.78;
      if (z > 14 && Math.abs(x) < 7) continue;
      positions.push(new Vector2(x, z));
    }
    for (let index = 0; index < positions.length; index += 1) {
      const position = positions[index];
      const tree = this.instantiateStatic(R13_WORLD_MODELS.pines[index % R13_WORLD_MODELS.pines.length], `snow-pine-${index}`);
      tree.position.set(position.x, this.heightAt(position.x, position.y), position.y);
      // R13 pines are authored in real metres (3.15–4.9 m).  The retired
      // Kenney sources needed a much larger instance multiplier; retaining it
      // would create 15 m foreground trees that occlude the shop and pasture.
      const scale = 0.82 + random() * 0.65;
      tree.scaling.set(scale * (0.92 + random() * 0.16), scale, scale * (0.92 + random() * 0.16));
      tree.rotation.y = random() * Math.PI * 2;
      if (index % 4 === 0) {
        const rock = this.instantiateStatic(R13_WORLD_MODELS.rocks[index % R13_WORLD_MODELS.rocks.length], `forest-rock-${index}`);
        rock.position.set(position.x + 1.4, this.heightAt(position.x + 1.4, position.y - 0.7), position.y - 0.7);
        rock.rotation.y = random() * Math.PI;
        rock.scaling.setAll(1.2 + random());
      }
    }
  }

  private buildWayfinding(): void {
    const pathMaterial = new PBRMaterial("trampled-snow", this.scene);
    pathMaterial.albedoColor = new Color3(0.42, 0.52, 0.55);
    pathMaterial.roughness = 1;
    const points = [new Vector3(-8, 0, -7.1), new Vector3(-5.3, 0, -4.5), new Vector3(-1.5, 0, -1.4), new Vector3(3.2, 0, 1.5), new Vector3(7, 0, 3.5)];
    for (let index = 0; index < points.length - 1; index += 1) {
      const start = points[index];
      const end = points[index + 1];
      const midpoint = start.add(end).scale(0.5);
      const length = Vector3.Distance(start, end);
      const path = MeshBuilder.CreateCapsule(`snow-path-${index}`, { height: length, radius: 0.72, tessellation: 10 }, this.scene);
      path.scaling.z = 0.12;
      path.rotation.x = Math.PI / 2;
      path.rotation.y = Math.atan2(end.x - start.x, end.z - start.z);
      path.position.set(midpoint.x, this.heightAt(midpoint.x, midpoint.z) + 0.025, midpoint.z);
      path.material = pathMaterial;
      path.receiveShadows = Boolean(this.shadows);
    }
  }

  private createActors(): void {
    const protagonist = PROTAGONISTS.find((entry) => entry.id === this.state.protagonistId)!;
    this.player = this.instantiateActor(protagonist.model, `player-${protagonist.id}`, new Vector3(-0.5, 0, -1.5), 1);
    this.player.root.position.y = this.heightAt(this.player.root.position.x, this.player.root.position.z);
    this.playAnimation(this.player, "idle", true);
    this.addActorShadows(this.player);

    this.cow = {
      ...this.instantiateActor(R13_WORLD_MODELS.cowBrown, "pasture-cow", PASTURE_CENTER, 0.82),
      hp: 3,
      maxHp: 3,
      meatYield: 3,
      strong: false,
      alive: true,
      isMoving: false,
      behaviorTimer: 4,
      roamTarget: PASTURE_CENTER.clone(),
      pastureCenter: PASTURE_CENTER.clone(),
    };
    this.cow.root.position.y = this.heightAt(this.cow.root.position.x, this.cow.root.position.z);
    this.cow.root.rotation.y = -0.7;
    this.playAnimation(this.cow, "Eating", true);
    this.addActorShadows(this.cow);

    for (const definition of R10_ANONYMOUS_CUSTOMERS) {
      const actor: CustomerActor = {
        ...this.instantiateActor(definition.model, `wandering-customer-${definition.id}`, new Vector3(-18, 0, -10), 1),
        phase: "hidden",
        timer: 0,
        identity: null,
      };
      this.customerVariants.set(definition.id, actor);
    }
    for (const definition of NAMED_CUSTOMERS) {
      const actor: CustomerActor = {
        ...this.instantiateActor(definition.model, `customer-${definition.id}`, new Vector3(-18, 0, -10), 1),
        phase: "hidden",
        timer: 0,
        identity: definition.id,
      };
      this.customerVariants.set(definition.id, actor);
    }
    for (const actor of this.customerVariants.values()) {
      actor.root.setEnabled(false);
      this.addActorShadows(actor);
    }
    this.customer = this.customerVariants.get("anonymous-traveler")!;
  }

  private createTowers(): void {
    const towerColors: Record<TowerId, Color3> = {
      ballista: new Color3(0.16, 0.48, 0.55),
      frost: new Color3(0.25, 0.72, 0.94),
      cannon: new Color3(0.72, 0.27, 0.15),
    };
    for (const definition of TOWERS) {
      const id = definition.id;
      const position = TOWER_POSITIONS[id];
      const pad = MeshBuilder.CreateCylinder(`${id}-tower-build-pad`, { diameter: 3.1, height: 0.16, tessellation: 32 }, this.scene);
      pad.position.set(position.x, this.heightAt(position.x, position.z) + 0.04, position.z);
      const padMaterial = new PBRMaterial(`${id}-tower-pad-material`, this.scene);
      padMaterial.albedoColor = towerColors[id];
      padMaterial.emissiveColor = towerColors[id].scale(0.7);
      padMaterial.emissiveIntensity = 0.65;
      padMaterial.metallic = 0.2;
      padMaterial.roughness = 0.45;
      padMaterial.alpha = 0.72;
      pad.material = padMaterial;
      this.tagWorldAction(pad, { type: "tower", id });

      const towerFile: Record<TowerId, string> = {
        ballista: "custom/tower-ballista.glb",
        frost: "custom/tower-frost.glb",
        cannon: "custom/tower-cannon.glb",
      };
      const actor = this.instantiateActor(
        towerFile[id],
        `${id}-custom-tower`,
        new Vector3(position.x, this.heightAt(position.x, position.z), position.z),
        1,
      );
      const weapon = actor.root.getChildTransformNodes(false).find((node) => node.name.includes("AimPivot")) ?? actor.root;
      weapon.rotationQuaternion = null;
      this.tagWorldAction(actor.root, { type: "tower", id });
      actor.root.setEnabled(this.state.towers[id] > 0);
      pad.setEnabled(this.state.towers[id] === 0);
      this.towerActors.set(id, { ...actor, id, weapon, pad, cooldown: 0, animationLodPaused: false });
    }
  }

  private createMeatDisplays(): void {
    for (let index = 0; index < 6; index += 1) {
      const carried = this.createMeatPiece(`carried-meat-${index}`, 0.36);
      carried.parent = this.player.root;
      carried.position.set((index % 2 - 0.5) * 0.46, 1.05 + Math.floor(index / 2) * 0.27, -0.32 - Math.floor(index / 2) * 0.05);
      carried.rotation.set(0.15, (index % 2) * 0.45 - 0.22, Math.PI / 2);
      carried.setEnabled(false);
      this.carriedVisuals.push(carried);

      const stock = this.createMeatPiece(`stall-meat-${index}`, 0.44);
      stock.position.set(-9.55 + (index % 3) * 1.55, this.heightAt(-8, -6.85) + 1.2 + Math.floor(index / 3) * 0.35, -6.85);
      stock.rotation.set(0.05, 0.25 * index, Math.PI / 2);
      stock.setEnabled(false);
      this.stockVisuals.push(stock);
    }
    this.updateMeatVisuals();
  }

  private update(dt: number): void {
    this.elapsed += dt;
    this.updateAtmosphere(dt);
    this.updateCombatVfx(dt);
    if (!this.player) return;
    this.updateCamera(dt);
    this.updateDrops(dt);
    this.updateCustomer(dt);
    this.updateCow(dt);
    this.updateStaff(dt);
    this.updateR23Feedback(dt);
    if (!this.started || this.endShown) return;

    this.attackCooldown = Math.max(0, this.attackCooldown - dt);
    for (const tower of this.towerActors.values()) tower.cooldown = Math.max(0, tower.cooldown - dt);
    this.handleMovement(dt);
    this.updatePlayerAttack(dt);
    // R23 手感：按住攻擊鍵所有武器都會在收勢結束後自動接下一擊（仍走完整前搖／命中／收勢）
    const attackRequested = this.input.consumeAttack() || this.input.isAttackHeld;
    if (attackRequested) this.performAttack();
    if (this.input.consumeBuild()) this.buyOrUpgradeTower("ballista");
    if (this.input.consumeWave()) this.tryStartWave();
    if (this.input.consumeBait()) this.throwBait();
    this.autoDeposit();
    this.updateWave(dt);
    this.updateTowers(dt);
    this.updateProjectiles(dt);
    this.processQuests();
    this.updateContextPrompt();
    this.statsTimer += dt;
    if (this.statsTimer >= 0.5) {
      this.statsTimer = 0;
      this.state.currentFps = this.engine.getFps();
      this.state.drawCalls = this.instrumentation.drawCallsCounter.current;
      (window as Window & { __stormDebug?: unknown }).__stormDebug = {
        fps: Math.round(this.state.currentFps),
        drawCalls: this.state.drawCalls,
        activeMeshes: this.scene.getActiveMeshes().length,
        totalMeshes: this.scene.meshes.length,
        quality: this.state.quality,
        targetFps: 30,
        renderPixelRatio: this.renderPixelRatio,
        performanceTier: this.performanceTier,
        shadowMode: this.shadows ? "realtime" : "blob",
        fogDensity: this.scene.fogDensity,
        weather: {
          intensity: this.weatherIntensity,
          farRate: Math.round(this.snowParticles?.emitRate ?? 0),
          nearRate: Math.round(this.nearSnowParticles?.emitRate ?? 0),
          density: this.weatherDensityMultiplier(),
          behavior: weatherBehaviorSignature(WEATHER_PROFILES[this.weatherIntensity]),
        },
        wave: this.state.wave,
        enemies: this.state.enemiesRemaining,
        playerPosition: { x: Number(this.player.root.position.x.toFixed(2)), z: Number(this.player.root.position.z.toFixed(2)) },
        hardwareInstancing: true,
        waveMetrics: {
          stockAtStart: this.waveStartedStock,
          playerKills: this.wavePlayerKills,
          towerKills: this.waveTowerKills,
          seconds: this.state.waveActive ? Math.round((performance.now() - this.waveStartTime) / 1000) : 0,
        },
        combatVfx: {
          assets: R13_VFX_FILES.length,
          events: this.vfxEventCount,
          active: this.combatVfx.length,
          lastAt: Number(this.lastVfxAt.toFixed(3)),
        },
        feedback: {
          towerPreview: this.selectedPreviewTower,
          baitAim: this.baitAimPosition ? { x: this.baitAimPosition.x, z: this.baitAimPosition.z } : null,
          baitPosition: this.bait ? { x: this.bait.position.x, z: this.bait.position.z } : null,
          baitScraps: this.baitScraps,
          patrolStamps: this.patrol.completedWaves.length,
          supply: this.waveSupply,
          waveEvent: this.currentWavePlan?.event,
          enemyTypes: [...new Set(this.zombies.map(zombie => zombie.type))],
          hitStops: this.hitStops,
          hitFlashes: this.hitFlashes,
          floaters: this.floaterCount,
          combo: this.combo.count,
          bestCombo: this.runBestCombo,
          baitsThrown: this.baitsThrown,
          baitedZombies: this.baitedZombies,
          baitActive: Boolean(this.bait),
          baitCooldown: Number(this.baitCooldown.toFixed(2)),
          beacon: this.beaconTarget,
          fadedOccluders: this.fadedOccluders.size,
          lastWaveGrade: this.lastWaveGrade,
        },
      };
    }
    this.uiUpdateTimer += dt;
    // HUD values are informational; updating the complete DOM tree at render
    // frequency causes periodic layout frames on dense desktop scenes. Keep
    // gameplay/animation at full rate and publish UI state at a stable 10 Hz.
    if (this.uiUpdateTimer >= 0.1) {
      this.uiUpdateTimer = 0;
      this.ui.update(this.state);
      this.ui.updatePatrol(this.patrol, this.state.waveActive, this.state.wave + 1, {
        attracted: this.baitedZombies - this.waveAttractedStart, playerKills: this.wavePlayerKills, wallDamage: this.waveWallDamage,
      });
    }
  }

  private handleMovement(dt: number): void {
    const movement = this.input.movement;
    const moving = movement.lengthSquared() > 0.015;
    if (moving) {
      const direction = new Vector3(movement.x, 0, movement.y).normalize();
      const next = this.player.root.position.add(direction.scale(4.15 * dt));
      next.x = Math.max(-24, Math.min(24, next.x));
      next.z = Math.max(-20, Math.min(20, next.z));
      next.y = this.heightAt(next.x, next.z);
      this.player.root.position.copyFrom(next);
      if (!this.state.stats.pastureVisited && Vector3.Distance(next, PASTURE_CENTER) < 5.5) this.state.stats.pastureVisited = true;
      const targetRotation = Math.atan2(direction.x, direction.z);
      this.player.root.rotation.y = this.lerpAngle(this.player.root.rotation.y, targetRotation, Math.min(1, dt * 13));
      if (!this.isAttackAnimation(this.player)) this.playAnimation(this.player, "run", true);
    } else if (this.attackCooldown <= 0) {
      if (!this.isAttackAnimation(this.player)) this.playAnimation(this.player, "idle", true);
    }
  }

  private performAttack(): void {
    if (this.attackCooldown > 0) return;
    this.attackCount += 1;
    const renderCanvas = this.engine.getRenderingCanvas();
    if (renderCanvas) renderCanvas.dataset.lastAttack = Math.round(performance.now()).toString();
    const weapon = this.state.weapon;
    const attack = playerAttackStats(weapon, this.state.protagonistId);
    this.attackCooldown = attack.recovery;
    this.pendingPlayerAttack = { weapon, elapsed: 0, impactAt: attack.impact, recoveryAt: attack.recovery, resolved: false };
    this.playAnimation(this.player, weapon === "smg" ? "attack_ranged" : "attack_melee", false, true);
    this.audio.play("swing");
  }

  private updatePlayerAttack(dt: number): void {
    const attack = this.pendingPlayerAttack;
    if (!attack) return;
    attack.elapsed += dt;
    if (!attack.resolved && attack.elapsed >= attack.impactAt) {
      attack.resolved = true;
      this.resolvePlayerAttack(attack.weapon);
    }
    if (attack.elapsed >= attack.recoveryAt) this.pendingPlayerAttack = undefined;
  }

  private playerAttackPhase(): "idle" | "anticipation" | "impact" | "recovery" {
    const attack = this.pendingPlayerAttack;
    if (!attack) return "idle";
    if (!attack.resolved) return "anticipation";
    if (attack.elapsed <= attack.impactAt + 1 / 24) return "impact";
    return "recovery";
  }

  private resolvePlayerAttack(weapon: WeaponId): void {
    const attack = playerAttackStats(weapon, this.state.protagonistId);
    const hitDamages = resolvedPlayerHitDamages(attack, Math.random());
    const critical = hitDamages[0] > attack.hitDamages[0];
    const total = hitDamages.reduce((sum, damage) => sum + damage, 0);
    const victims: Vector3[] = [];
    let hit = false;
    if (weapon === "smg") {
      if (this.muzzleFlash) {
        this.muzzleFlash.setEnabled(true);
        window.setTimeout(() => this.muzzleFlash?.setEnabled(false), 70);
      }
      const target = this.findNearestZombie(this.player.root.position, attack.range) ?? this.findNearestCow(this.player.root.position, 16);
      if (target && "type" in target) {
        victims.push(target.root.position.clone());
        for (const damage of hitDamages) this.damageZombie(target, damage, "player");
        hit = true;
      } else if (target) {
        victims.push(target.root.position.clone());
        for (const damage of hitDamages) this.damageCow(target, damage);
        hit = true;
      }
    } else if (weapon === "axe") {
      const targets = this.zombies.filter((zombie) => zombie.alive && Vector3.Distance(zombie.root.position, this.player.root.position) < attack.range);
      for (const zombie of targets) {
        victims.push(zombie.root.position.clone());
        for (const damage of hitDamages) this.damageZombie(zombie, damage, "player");
      }
      const cows = this.allCows().filter((cow) => cow.alive && Vector3.Distance(cow.root.position, this.player.root.position) < attack.range);
      for (const cow of cows) {
        victims.push(cow.root.position.clone());
        for (const damage of hitDamages) this.damageCow(cow, damage);
      }
      this.createAttackRing(new Color3(0.95, 0.55, 0.24));
      hit = targets.length + cows.length > 0;
    } else {
      const nearestZombie = this.findNearestZombie(this.player.root.position, attack.range);
      if (nearestZombie) {
        victims.push(nearestZombie.root.position.clone());
        for (const damage of hitDamages) this.damageZombie(nearestZombie, damage, "player");
        hit = true;
      } else {
        const nearestCow = this.findNearestCow(this.player.root.position, 2.8);
        if (nearestCow) {
          victims.push(nearestCow.root.position.clone());
          for (const damage of hitDamages) this.damageCow(nearestCow, damage);
          hit = true;
        }
      }
    }
    // R23：每個受擊目標一個傷害數字（衝鋒槍三連發合併顯示），暴擊放大金色
    for (const position of victims.slice(0, 6)) this.showFloater(position.add(new Vector3(0, 2.1, 0)), critical ? `暴擊 ${total}` : `${total}`, critical ? "crit" : "hit");
    if (hit) {
      this.audio.play("hit");
      this.kickCameraShake(weapon === "smg" ? 0.08 : weapon === "axe" ? 0.2 : 0.14);
      if (weapon !== "smg") {
        this.hitStopTimer = weapon === "axe" ? 0.075 : 0.06;
        this.hitStops += 1;
      }
    } else {
      this.showFloater(this.player.root.position.add(new Vector3(0, 2.4, 0)), "落空", "miss");
    }
  }

  private damageCow(cow: CowActor, damage: number): void {
    if (!cow.alive) return;
    cow.hp -= damage;
    this.damageEventCount += 1;
    this.lastDamageAt = this.elapsed;
    this.triggerGroundImpactVfx(cow.root.position);
    this.playAnimation(cow, cow.hp > 0 ? "Idle_HitReact1" : "Death", false);
    if (cow.hp <= 0) this.killCow(cow);

  }

  private killCow(cow: CowActor): void {
    if (!cow.alive) return;
    cow.alive = false;
    this.state.stats.cowsKilled += 1;
    this.playAnimation(cow, "Death", false);
    this.ui.toast(`${cow.strong ? "強化牛" : "牛隻"}倒下 · 掉落 ${cow.meatYield} 份肉`, "warm");
    for (let index = 0; index < cow.meatYield; index += 1) {
      const root = this.createMeatPiece(`meat-drop-${this.elapsed}-${index}`, 0.55);
      const angle = index / cow.meatYield * Math.PI * 2 + 0.3;
      root.position.set(cow.root.position.x + Math.cos(angle) * 0.9, cow.root.position.y + 0.45, cow.root.position.z + Math.sin(angle) * 0.9);
      root.rotation.set(0.2, angle, Math.PI / 2);
      this.drops.push({ root, baseY: root.position.y, phase: index * 2.1, expiresAt: this.elapsed + 45 + index * 0.6 });
    }
    saveState(this.state);
    window.setTimeout(() => cow.root.setEnabled(false), 1100);
    window.setTimeout(() => {
      const center = cow.pastureCenter;
      cow.root.position.set(center.x + 1.2, this.heightAt(center.x + 1.2, center.z - 1), center.z - 1);
      cow.root.setEnabled(true);
      cow.hp = cow.maxHp;
      cow.alive = true;
      cow.behaviorTimer = 3;
      this.playAnimation(cow, "Eating", true);
      this.ui.toast(`${cow.strong ? "第二牧場的強化牛" : "牧場牛隻"}已重返圍欄。`, "ice");
    }, cow.strong ? 12000 : 7000);
  }

  private updateDrops(dt: number): void {
    for (let index = this.drops.length - 1; index >= 0; index -= 1) {
      const drop = this.drops[index];
      if (drop.expiresAt <= this.elapsed) {
        drop.root.dispose(false, false);
        this.drops.splice(index, 1);
        continue;
      }
      drop.phase += dt * 2.7;
      drop.root.position.y = drop.baseY + Math.sin(drop.phase) * 0.12;
      drop.root.rotation.y += dt * 0.7;
      if (!this.started || this.state.carriedMeat >= 6 || Vector3.Distance(drop.root.position, this.player.root.position) > 1.55) continue;
      drop.root.dispose(false, false);
      this.drops.splice(index, 1);
      this.state.carriedMeat += 1;
      this.state.stats.meatCollected += 1;
      this.updateMeatVisuals();
      this.ui.toast(`肉品裝袋 · ${this.state.carriedMeat} / 6`, "warm");
    }
  }

  private autoDeposit(): void {
    if (this.state.carriedMeat <= 0 || Vector3.Distance(this.player.root.position, STALL_POSITION) > 2.65) return;
    const available = this.state.stallLevel * 6 - this.state.displayedMeat;
    const deposited = Math.min(available, this.state.carriedMeat);
    if (deposited <= 0) return;
    this.state.carriedMeat -= deposited;
    this.state.displayedMeat += deposited;
    this.state.stats.meatDeposited += deposited;
    this.updateMeatVisuals();
    this.customerCooldown = Math.min(this.customerCooldown, 0.6);
    this.ui.toast(`${deposited} 份肉品已陳列，顧客正在前來。`, "warm");
  }

  private updateCustomer(dt: number): void {
    if (!this.customer) return;
    if (this.state.waveActive) return;
    if (this.customer.phase === "hidden") {
      this.customerCooldown -= dt;
      if (this.started && this.state.displayedMeat > 0 && this.customerCooldown <= 0) this.spawnCustomer();
      return;
    }
    if (this.customer.phase === "arriving") {
      if (this.moveActorToward(this.customer, STALL_POSITION.add(new Vector3(0, 0, 1.3)), 2.25, dt)) {
        this.customer.phase = "buying";
        this.customer.timer = this.state.employees.cashier >= 2 ? 0.28 : this.state.employees.cashier >= 1 ? 0.38 : 1.15;
        this.playAnimation(this.customer, "Idle", true);
      }
      return;
    }
    if (this.customer.phase === "buying") {
      this.customer.timer -= dt;
      if (this.customer.timer <= 0) {
        if (this.state.displayedMeat > 0) {
          this.state.displayedMeat -= 1;
          const income = this.meatSaleIncome();
          creditIncome(this.state, income);
          this.state.stats.sales += 1;
          if (this.customer.identity) this.addCustomerAffinity(this.customer.identity);
          this.updateMeatVisuals();
          saveState(this.state);
          this.audio.play("sale");
          const customer = NAMED_CUSTOMERS.find((entry) => entry.id === this.customer.identity);
          this.ui.toast(`${customer ? customer.name : "交易"}結帳 · 收入 ✦ ${income}`, "warm");
        }
        this.customer.phase = "leaving";
        this.playAnimation(this.customer, "Walk", true);
      }
      return;
    }
    if (this.moveActorToward(this.customer, new Vector3(-18, 0, -10), 2.5, dt)) {
      this.customer.root.setEnabled(false);
      this.customer.phase = "hidden";
      this.customerCooldown = this.state.employees.cashier >= 2 ? 1.9 : 2.2;
    }
  }

  private spawnCustomer(): void {
    this.customer.root.setEnabled(false);
    const familiarCount = NAMED_CUSTOMERS.filter((entry) => this.state.customerAffinity[entry.id] >= 6).length;
    const anonymousWeight = Math.max(0.35, 0.55 - familiarCount * 0.04);
    const weights: Array<[NamedCustomerId | AnonymousCustomerVariant, number]> = [
      ...R10_ANONYMOUS_CUSTOMERS.map((entry) => [entry.id, anonymousWeight / R10_ANONYMOUS_CUSTOMERS.length] as [AnonymousCustomerVariant, number]),
      ...NAMED_CUSTOMERS.map((entry) => [entry.id, entry.weight + (this.state.customerAffinity[entry.id] >= 6 ? 0.04 : 0)] as [NamedCustomerId, number]),
    ];
    const total = weights.reduce((sum, entry) => sum + entry[1], 0);
    let draw = Math.random() * total;
    let selected: NamedCustomerId | AnonymousCustomerVariant = "anonymous-traveler";
    for (const [id, weight] of weights) {
      draw -= weight;
      if (draw <= 0) {
        selected = id;
        break;
      }
    }
    this.customer = this.customerVariants.get(selected)!;
    this.customer.root.position.set(-18, this.heightAt(-18, -10), -10);
    this.customer.root.setEnabled(true);
    this.customer.phase = "arriving";
    this.playAnimation(this.customer, "Walk", true);
    const named = this.customer.identity ? NAMED_CUSTOMERS.find((entry) => entry.id === this.customer.identity) : undefined;
    // R17（辯論裁決 B-03）：好感三段對白（0-2 低／3-5 中／6+ 高），資料源既有 customerAffinity
    let arrival = named ? named.arrivalLine : "";
    if (named) {
      const affinity = this.state.customerAffinity[named.id] ?? 0;
      arrival = affinity >= 6 ? named.arrivalLineHigh : affinity >= 3 ? named.arrivalLineMid : named.arrivalLine;
    }
    this.ui.toast(named ? `${named.name} · ${named.role}：「${arrival}」` : "遠方的旅人正朝肉舖走來。", "ice");
  }

  private meatSaleIncome(): number {
    const cashierBonus = this.state.employees.cashier >= 2 ? 8 : this.state.employees.cashier >= 1 ? 5 : 0;
    let income = 20 + cashierBonus + (this.state.pasture2Unlocked ? 5 : 0);
    if (this.state.protagonistId === "butcher_matron") income = Math.floor(income * 1.1);
    if (this.state.customerAffinity.lao_zhou >= 6) income += 1;
    if (this.state.customerAffinity.kid_bao >= 6 && Math.random() < 0.05) {
      income += 5;
      this.ui.toast("小包把扣子換成真正的硬幣 · 小費 ✦ 5", "warm");
    }
    return income;
  }

  private addCustomerAffinity(id: NamedCustomerId): void {
    if (this.state.customerAffinityWave !== this.state.wave) {
      this.state.customerAffinityWave = this.state.wave;
      this.state.customerAffinityGained = { lao_zhou: 0, nurse_lin: 0, kid_bao: 0, scout_he: 0 };
    }
    let requested = 1;
    if (id === "lao_zhou" && this.state.employees.cashier >= 1) requested += 1;
    if (id === "nurse_lin" && (this.stockedAtCycleStart || this.state.wave === 0 && this.state.displayedMeat >= 1)) requested += 1;
    if (id === "kid_bao" && this.state.protagonistId === "butcher_matron") requested += 1;
    if (id === "scout_he" && (this.state.weapon !== "machete" || Object.values(this.state.towers).some((level) => level > 0))) requested += 1;
    const allowance = Math.max(0, 2 - this.state.customerAffinityGained[id]);
    const gain = Math.min(requested, allowance, 10 - this.state.customerAffinity[id]);
    if (gain <= 0) return;
    this.state.customerAffinity[id] += gain;
    this.state.customerAffinityGained[id] += gain;
    const customer = NAMED_CUSTOMERS.find((entry) => entry.id === id)!;
    let thresholdCrossed = false;
    for (const threshold of [3, 6, 10] as const) {
      if (this.state.customerAffinity[id] < threshold) continue;
      const rewardId = `aff_${id}_${threshold}`;
      if (this.state.customerRewardsClaimed.includes(rewardId)) continue;
      this.state.customerRewardsClaimed.push(rewardId);
      thresholdCrossed = true;
      if (threshold === 3) {
        creditIncome(this.state, 40);
        this.ui.toast(`${customer.name}開始認得這間店了 · ✦ 40`, "warm");
      } else if (threshold === 6) {
        this.ui.toast(`${customer.name}成了真正的常客 · ${customer.affinityBonus}`, "warm");
      } else {
        creditIncome(this.state, 120);
        if (!this.state.quest.unlocks.includes(customer.friendMark)) this.state.quest.unlocks.push(customer.friendMark);
        this.ui.toast(`${customer.name}把命也算在這盞燈上 · ✦ 120 · ${customer.friendMarkName}`, "warm");
      }
    }
    // R18 C-01：好感成長可視化——非門檻回合也給輕量回饋（每客每波 allowance ≤ 2 天然限流）
    if (!thresholdCrossed) this.ui.toast(`${customer.name} 好感 +${gain}（${this.state.customerAffinity[id]} / 10）`, "ice");
  }

  private updateCow(dt: number): void {
    for (const cow of this.allCows()) {
      if (!cow.alive) continue;
      cow.behaviorTimer -= dt;
      if (cow.behaviorTimer <= 0) {
        cow.isMoving = !cow.isMoving;
        cow.behaviorTimer = cow.isMoving ? 3 + Math.sin(this.elapsed) : 4.5 + Math.cos(this.elapsed);
        if (cow.isMoving) {
          const angle = this.elapsed * (cow.strong ? 1.23 : 1.7);
          cow.roamTarget.set(cow.pastureCenter.x + Math.cos(angle) * 3.1, 0, cow.pastureCenter.z + Math.sin(angle * 1.31) * 2.6);
          this.playAnimation(cow, "Walk", true);
        } else {
          this.playAnimation(cow, "Eating", true);
        }
      }
      if (cow.isMoving) this.moveActorToward(cow, cow.roamTarget, cow.strong ? 0.62 : 0.75, dt);
    }
  }

  private buyWeapon(id: WeaponId): void {
    const item = WEAPONS.find((weapon) => weapon.id === id);
    if (!item || this.state.waveActive) return;
    if (this.state.weapons[id]) {
      this.equipWeapon(id, true);
      return;
    }
    const unlockChapter = id === "axe" ? SHOP_UNLOCK_CHAPTER.axe : SHOP_UNLOCK_CHAPTER.smg;
    if (!this.requireChapter(unlockChapter)) return;
    if (id === "smg" && !this.state.weapons.axe) {
      this.ui.toast("先掌握迴旋斧，才能購買衝鋒槍。", "danger");
      return;
    }
    if (this.state.money < item.price) {
      this.ui.toast(`購買${item.name}尚缺 ✦ ${item.price - this.state.money}`, "danger");
      return;
    }
    this.state.money -= item.price;
    this.state.weapons[id] = true;
    this.equipWeapon(id);
    this.ui.toast(`武器已解鎖：${item.name}`, "warm");
    this.processQuests();
  }

  private equipWeapon(id: WeaponId, announce = false): void {
    if (!this.state.weapons[id]) return;
    if (this.state.weapon === id) {
      if (announce) this.ui.toast(`目前武器：${WEAPONS.find((weapon) => weapon.id === id)!.name}`, "ice");
      return;
    }
    this.state.weapon = id;
    this.createWeaponModel();
    saveState(this.state);
    this.ui.update(this.state);
    if (announce) this.ui.toast(`切換武器：${WEAPONS.find((weapon) => weapon.id === id)!.name}`, "ice");
    this.processQuests();
  }

  private hireEmployee(id: EmployeeId): void {
    const item = EMPLOYEES.find((employee) => employee.id === id);
    const level = this.state.employees[id];
    if (!item || level >= 2 || this.state.waveActive) return;
    const unlockChapter = level === 0 ? SHOP_UNLOCK_CHAPTER.employeeShop : SHOP_UNLOCK_CHAPTER.employeeUpgrade;
    if (!this.requireChapter(unlockChapter)) return;
    const price = level === 0 ? item.price : item.upgradePrice ?? 0;
    if (this.state.money < price) {
      this.ui.toast(`${level === 0 ? "雇用" : "升級"}${item.name}尚缺 ✦ ${price - this.state.money}`, "danger");
      return;
    }
    this.state.money -= price;
    this.state.employees[id] = level === 0 ? 1 : 2;
    if (level === 0) this.createStaff(id);
    saveState(this.state);
    this.ui.toast(level === 0 ? `${item.name}已加入肉舖。自動化開始運轉。` : `${item.name}已升至 Lv2 · ${item.upgradeDescription}`, "warm");
    this.processQuests();
  }

  private unlockPasture2(): void {
    if (this.state.pasture2Unlocked || this.state.waveActive) return;
    if (!this.requireChapter(SHOP_UNLOCK_CHAPTER.pasture2)) return;
    if (this.state.money < 260) {
      this.ui.toast(`炸開第二牧場尚缺 ✦ ${260 - this.state.money}`, "danger");
      return;
    }
    this.state.money -= 260;
    this.state.pasture2Unlocked = true;
    this.createStrongCow();
    this.createExplosion(PASTURE_2_CENTER.add(new Vector3(-3.5, 0, 0)), 4.2);
    saveState(this.state);
    this.ui.toast("林線已炸開！第二牧場出現強化牛。", "warm");
    this.processQuests();
  }

  private buyOrUpgradeTower(id: TowerId): void {
    if (this.state.waveActive) {
      this.ui.toast("夜襲中無法施工。", "danger");
      return;
    }
    const tower = this.towerActors.get(id);
    const definition = TOWERS.find((entry) => entry.id === id);
    if (!tower || !definition) return;
    const level = this.state.towers[id];
    if (level >= 3) return;
    const unlockChapter = level === 0 ? SHOP_UNLOCK_CHAPTER.defenseShop : SHOP_UNLOCK_CHAPTER.towerUpgrade;
    if (!this.requireChapter(unlockChapter)) return;
    const cost = towerCostForState(this.state, id, level);
    if (this.state.money < cost) {
      this.ui.toast(`${level === 0 ? "建造" : "升級"}${definition.name}尚缺 ✦ ${cost - this.state.money}`, "danger");
      return;
    }
    this.state.money -= cost;
    this.state.towers[id] = level + 1;
    this.state.towerBuilt = this.state.towers.ballista > 0;
    tower.root.setEnabled(true);
    tower.pad.setEnabled(false);
    tower.root.scaling.setAll(level === 0 ? 0.01 : 1);
    const animateBuild = (): void => {
      const current = tower.root.scaling.x;
      const next = Math.min(1, current + 0.085);
      tower.root.scaling.setAll(next + Math.sin(next * Math.PI) * 0.08);
      if (next < 1) requestAnimationFrame(animateBuild);
      else tower.root.scaling.setAll(1 + this.state.towers[id] * 0.025);
    };
    animateBuild();
    this.createAttackRing(id === "frost" ? new Color3(0.25, 0.76, 1) : id === "cannon" ? new Color3(1, 0.31, 0.08) : new Color3(0.86, 0.66, 0.32), tower.root.position);
    saveState(this.state);
    this.audio.play("build");
    this.ui.toast(`${definition.name}${level === 0 ? "完工" : `升至 Lv.${level + 1}`}。`, "warm");
    this.processQuests();
  }

  private syncUnlockedContent(): void {
    if (this.state.pasture2Unlocked) this.createStrongCow();
    for (const id of Object.keys(this.state.employees) as EmployeeId[]) {
      if (this.state.employees[id]) this.createStaff(id);
    }
  }

  private createStrongCow(): void {
    if (this.strongCow) return;
    for (const node of this.scene.transformNodes) {
      if ((node.name.startsWith("snow-pine-") || node.name.startsWith("forest-rock-")) && Vector3.Distance(node.position, PASTURE_2_CENTER) < 6.2) node.setEnabled(false);
    }
    const fenceOffsets: Array<[number, number, number]> = [];
    for (let offset = -4; offset <= 4; offset += 2) {
      fenceOffsets.push([offset, -4.2, 0], [offset, 4.2, 0], [-5, offset, Math.PI / 2], [5, offset, Math.PI / 2]);
    }
    for (const [x, z, rotation] of fenceOffsets) {
      const fence = this.instantiateStatic(R13_WORLD_MODELS.fence, `pasture-2-fence-${x}-${z}`);
      const px = PASTURE_2_CENTER.x + x;
      const pz = PASTURE_2_CENTER.z + z;
      fence.position.set(px, this.heightAt(px, pz), pz);
      fence.rotation.y = rotation;
      fence.scaling.setAll(1.25);
      this.tagWorldAction(fence, { type: "pasture", id: "pasture2" });
    }
    const pastureRing = this.createWorldRing("pasture-2-unlocked-ring", PASTURE_2_CENTER, 9.2, new Color3(0.78, 0.29, 0.11));
    this.tagWorldAction(pastureRing, { type: "pasture", id: "pasture2" });
    this.strongCow = {
      ...this.instantiateActor(R13_WORLD_MODELS.cowStrong, "pasture-2-strong-cow", PASTURE_2_CENTER, 0.92),
      hp: 9,
      maxHp: 9,
      meatYield: 6,
      strong: true,
      alive: true,
      isMoving: false,
      behaviorTimer: 3.5,
      roamTarget: PASTURE_2_CENTER.clone(),
      pastureCenter: PASTURE_2_CENTER.clone(),
    };
    this.strongCow.root.position.y = this.heightAt(PASTURE_2_CENTER.x, PASTURE_2_CENTER.z);
    this.playAnimation(this.strongCow, "Eating", true);
    this.addActorShadows(this.strongCow);
  }

  private createStaff(id: EmployeeId): void {
    if (this.staff.has(id)) return;
    const position = id === "hunter"
      ? new Vector3(5.5, 0, 1)
      : id === "cashier"
        ? STALL_POSITION.add(new Vector3(1.7, 0, 1))
        : new Vector3(-5.8, 0, -5.5);
    const actor = this.instantiateActor(R10_STAFF_MODELS[id], `staff-${id}`, position, 1);
    actor.root.position.y = this.heightAt(position.x, position.z);
    this.playAnimation(actor, "idle", true);
    const staff: StaffActor = { ...actor, id, timer: 0, patrolIndex: 0, attackImpactTimer: 0 };
    this.addActorShadows(staff);
    this.tagWorldAction(staff.root, { type: "employee", id });
    this.staff.set(id, staff);
  }

  private updateStaff(dt: number): void {
    if (!this.started) return;
    const hunter = this.staff.get("hunter");
    if (hunter) {
      hunter.timer = Math.max(0, hunter.timer - dt);
      const hunterLevel = this.state.employees.hunter;
      const target = this.allCows().find((cow) => cow.alive);
      if (hunter.attackTarget) {
        hunter.attackImpactTimer -= dt;
        if (hunter.attackImpactTimer <= 0) {
          const attackTarget = hunter.attackTarget;
          hunter.attackTarget = undefined;
          if (attackTarget.alive && Vector3.Distance(hunter.root.position, attackTarget.root.position) <= 2.7) {
            this.damageCow(attackTarget, 1);
          }
        }
      } else if (target) {
        const distance = Vector3.Distance(hunter.root.position, target.root.position);
        if (distance > 2.35) {
          this.moveActorToward(hunter, target.root.position, hunterLevel >= 2 ? 2.4 : 2.15, dt);
          this.playAnimation(hunter, "run", true);
        } else if (hunter.timer <= 0) {
          hunter.timer = hunterLevel >= 2 ? 1.1 : 1.45;
          hunter.attackTarget = target;
          hunter.attackImpactTimer = 9 / 24;
          this.playAnimation(hunter, "attack", false, true);
        } else this.playAnimation(hunter, "idle", true);
      }
    }
    const cashier = this.staff.get("cashier");
    if (cashier) {
      const post = STALL_POSITION.add(new Vector3(1.7, 0, 1));
      if (Vector3.Distance(cashier.root.position, post) > 0.35) {
        this.moveActorToward(cashier, post, 1.7, dt);
        this.playAnimation(cashier, "walk", true);
      } else this.playAnimation(cashier, "idle", true);
    }
    const dog = this.staff.get("dog");
    if (dog) {
      const capacity = this.state.stallLevel * 6;
      const dogLevel = this.state.employees.dog;
      const drop = dogLevel >= 2
        ? this.drops.reduce<MeatDrop | undefined>((oldest, candidate) => !oldest || candidate.expiresAt < oldest.expiresAt ? candidate : oldest, undefined)
        : this.drops[0];
      if (drop && this.state.displayedMeat < capacity) {
        const reachedDrop = this.moveActorToward(dog, drop.root.position, dogLevel >= 2 ? 3.72 : 3.1, dt);
        this.playAnimation(dog, reachedDrop ? "idle" : "walk", true);
        if (reachedDrop) {
          const picked = [drop];
          if (dogLevel >= 2 && capacity - this.state.displayedMeat >= 2) {
            const second = this.drops
              .filter((candidate) => candidate !== drop && Vector3.Distance(candidate.root.position, drop.root.position) <= 2.5)
              .sort((a, b) => a.expiresAt - b.expiresAt)[0];
            if (second) picked.push(second);
          }
          for (const item of picked) {
            item.root.dispose(false, false);
            const index = this.drops.indexOf(item);
            if (index >= 0) this.drops.splice(index, 1);
          }
          this.state.displayedMeat += picked.length;
          this.state.stats.meatCollected += picked.length;
          this.state.stats.meatDeposited += picked.length;
          this.updateMeatVisuals();
          saveState(this.state);
        }
      } else {
        const post = STALL_POSITION.add(new Vector3(2.5, 0, -0.4));
        if (Vector3.Distance(dog.root.position, post) > 0.4) {
          this.moveActorToward(dog, post, dogLevel >= 2 ? 2.82 : 2.35, dt);
          this.playAnimation(dog, "walk", true);
        } else this.playAnimation(dog, "idle", true);
      }
    }
  }

  private tryStartWave(): void {
    if (!Object.values(this.state.towers).some((level) => level > 0) || this.state.waveActive || this.state.wave >= 30) return;
    this.ui.hideWorldAction();
    this.waveSupply = this.patrol.selected;
    const supply = supplyEffects(this.waveSupply);
    this.state.waveActive = true;
    this.state.baseHealth = Math.min(100, this.state.baseHealth + COMBAT_TIMING.waveRepair + supply.repair);
    const waveNumber = this.state.wave + 1;
    this.currentWavePlan = getWavePlan(waveNumber);
    this.enemiesToSpawn = this.currentWavePlan.enemyCount;
    this.spawnTimer = COMBAT_TIMING.waveSpawnDelay;
    this.state.enemiesRemaining = this.enemiesToSpawn;
    this.waveStartedStock = this.state.displayedMeat;
    this.stockedAtCycleStart = this.waveStartedStock >= 2;
    this.wavePlayerKills = 0;
    this.waveTowerKills = 0;
    this.waveWallDamage = 0;
    this.waveBestCombo = 0;
    this.baitCooldown = 0;
    this.baitScraps = supply.scraps;
    this.waveAttractedStart = this.baitedZombies;
    this.waveStartTime = performance.now();
    this.waveStockLost = false;
    assignLoopQuest(this.state, {
      wave: waveNumber,
      enemyCount: this.enemiesToSpawn,
      startingStock: this.waveStartedStock,
      startingHealth: this.state.baseHealth,
      hasStockThreat: this.currentWavePlan.event === "boss" || this.currentWavePlan.event === "elite_surge" || waveNumber >= 8 && this.enemiesToSpawn >= 5,
    });
    saveState(this.state);
    this.audio.play("wave");
    this.ui.toast(`警報：第 ${waveNumber} 波 · ${this.currentWavePlan.title}！${this.currentWavePlan.announcement}`, "danger");
    if (waveNumber <= 3 || this.baitsThrown === 0 && waveNumber % 4 === 0) {
      window.setTimeout(() => this.ui.toast(this.ui.touchMode ? "誘餌：輕點快投；拖曳瞄準，放開投擲。拖進取消區不扣肉。" : "招牌戰術：按 Q 丟一塊肉當誘餌，把屍群拉進塔的射界", "warm"), 3200);
    }
    { // R18 C-01：里程碑波前動員線——與完成廣播成對，強化波次間敘事節奏
      const eve = WAVE_EVE_DISPATCHES.find((entry) => entry.wave === waveNumber);
      if (eve) window.setTimeout(() => this.ui.toast(eve.line, "ice"), 1500);
    }
  }

  private updateWave(dt: number): void {
    if (!this.state.waveActive) return;
    if (this.enemiesToSpawn > 0) {
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) {
        this.spawnZombie(this.enemiesToSpawn);
        this.enemiesToSpawn -= 1;
        this.spawnTimer = this.currentWavePlan?.spawnInterval ?? Math.max(0.38, 0.86 - this.state.wave * 0.014);
      }
    }
    for (const zombie of this.zombies) {
      if (!zombie.alive) continue;
      zombie.slowTimer = Math.max(0, zombie.slowTimer - dt);
      const baited = this.bait && zombie.baitUntil > this.elapsed;
      if (baited && this.bait) {
        // R23 鮮肉誘餌：被吸引的殭屍改追誘餌，抵達後原地啃食（不攻擊壁壘）
        const feeding = Vector3.Distance(zombie.root.position, this.bait.position) <= BAIT_RULES.feedRange;
        if (!feeding) {
          const slowFactor = zombie.slowTimer > 0 ? COMBAT_TIMING.frostSlowFactor : 1;
          this.moveActorToward(zombie, this.bait.position, zombie.baseSpeed * slowFactor, dt);
          this.playAnimation(zombie, "Walk", true);
        } else {
          this.playAnimation(zombie, "Idle_Attack", true);
        }
        zombie.attackPhase = "approach";
        zombie.attackTimer = 0;
        continue;
      }
      const target = new Vector3(COMBAT_POSITIONS.barrierTarget.x, 0, COMBAT_POSITIONS.barrierTarget.z);
      const distance = Vector3.Distance(zombie.root.position, target);
      if (distance > COMBAT_TIMING.barrierAttackRange) {
        const slowFactor = zombie.slowTimer > 0 ? COMBAT_TIMING.frostSlowFactor : 1;
        this.moveActorToward(zombie, target, zombie.baseSpeed * slowFactor, dt);
        this.playAnimation(zombie, "Walk", true);
        zombie.attackPhase = "approach";
        zombie.attackTimer = 0;
      } else {
        const timings = enemyAttackTimings(zombie.type);
        if (zombie.attackPhase === "approach") {
          zombie.attackPhase = "anticipation";
          zombie.attackTimer = timings.impact;
          this.playAnimation(zombie, "Idle_Attack", false, true);
        } else {
          zombie.attackTimer -= dt;
        }
        if (zombie.attackPhase === "anticipation" && zombie.attackTimer <= 0) {
          const blocked = this.state.customerAffinity.nurse_lin >= 6 && Math.random() < COMBAT_TIMING.nurseBlockChance;
          const damage = Math.max(0, zombie.damage - (blocked ? COMBAT_TIMING.nurseBlockReduction : 0));
          this.state.baseHealth = Math.max(0, this.state.baseHealth - damage);
          this.state.stats.damageTaken += damage;
          this.waveWallDamage += damage;
          this.triggerBarrierHitVfx(target, this.state.baseHealth);
          zombie.attackPhase = "recovery";
          zombie.attackTimer = timings.recovery;
          if (blocked) this.ui.toast("林護理留下的繃帶穩住了壁壘 · 減免 1 傷", "ice");
          if ((zombie.type === "brute" || zombie.type === "boss") && this.state.displayedMeat > 0) {
            this.state.displayedMeat -= 1;
            this.waveStockLost = true;
            this.updateMeatVisuals();
          }
          this.kickCameraShake(zombie.type === "boss" ? 0.42 : zombie.type === "brute" ? 0.3 : 0.18);
          if (this.state.baseHealth <= 35 && this.elapsed - this.lastTowerAlarmAt >= 3.5) {
            this.lastTowerAlarmAt = this.elapsed;
            this.audio.play("towerAlarm");
          }
          saveState(this.state);
          this.ui.toast(`${this.zombieLabel(zombie.type)}正在破壞肉舖壁壘！`, "danger");
          if (this.state.baseHealth <= 0) {
            this.finishGame(false);
            return;
          }
        } else if (zombie.attackPhase === "recovery" && zombie.attackTimer <= 0) {
          zombie.attackPhase = "approach";
          zombie.attackTimer = 0;
        }
      }
    }
    this.updateZombieAnimationLod(dt);
    if (this.enemiesToSpawn === 0 && !this.zombies.some((zombie) => zombie.alive)) this.completeWave();
  }

  private updateZombieAnimationLod(dt: number): void {
    this.zombieAnimationLodTimer -= dt;
    if (this.zombieAnimationLodTimer > 0) return;
    this.zombieAnimationLodTimer = 0.3;
    const cap = this.performanceTier >= 1 ? 5 : this.state.quality === "低" ? 7 : 10;
    const walking = this.zombies
      .filter((zombie) => zombie.alive && zombie.currentAnimation.toLowerCase().includes("walk"))
      .sort((left, right) => Vector3.DistanceSquared(left.root.position, this.player.root.position)
        - Vector3.DistanceSquared(right.root.position, this.player.root.position));
    for (const [index, zombie] of walking.entries()) {
      const closeEnough = Vector3.DistanceSquared(zombie.root.position, this.player.root.position) < 11 * 11;
      const shouldAnimate = closeEnough || index < cap;
      const selected = zombie.animations.find((animation) => animation.name.toLowerCase().includes("walk"));
      if (!selected || shouldAnimate === !zombie.animationLodPaused) continue;
      if (shouldAnimate) selected.restart();
      else selected.pause();
      zombie.animationLodPaused = !shouldAnimate;
    }
  }

  private spawnZombie(order: number): void {
    const wave = this.state.wave + 1;
    const plan = this.currentWavePlan ?? getWavePlan(wave);
    const position = enemySpawnPosition(order);
    const { x, z } = position;
    const type: ZombieType = enemyTypeForWave(plan, order);
    const scale = type === "boss" ? 1.05 : type === "brute" ? 1.4 : type === "runner" ? 0.82 : 0.98;
    const zombieModel = type === "boss"
      ? "custom/boss-zombie.glb"
      : R8_ZOMBIE_MODELS[(wave + order) % R8_ZOMBIE_MODELS.length];
    const actor = this.instantiateActor(zombieModel, `zombie-${type}-${wave}-${order}-${this.elapsed}`, new Vector3(x, 0, z), scale);
    const stats = enemyCombatStats(wave, type, plan);
    const zombie: ZombieActor = {
      ...actor,
      hp: stats.hp,
      maxHp: stats.hp,
      alive: true,
      speed: stats.speed,
      baseSpeed: stats.speed,
      attackTimer: 0.2,
      attackPhase: "approach",
      damage: stats.damage,
      reward: stats.reward,
      type,
      slowTimer: 0,
      deathEndsAt: 0,
      animationLodPaused: false,
      baitUntil: 0,
      flashUntil: 0,
    };
    zombie.root.position.y = this.heightAt(x, z);
    if (type === "boss") {
      this.audio.play("boss");
      this.kickCameraShake(0.5);
      this.ui.toast("Boss 登場 · 巨型屍影撞進防線！", "danger");
    }
    this.playAnimation(zombie, "Walk", true);
    this.addActorShadows(zombie);
    this.addZombieTypeVisual(zombie);
    this.zombies.push(zombie);
  }

  private updateTowers(_dt: number): void {
    for (const tower of this.towerActors.values()) {
      const level = this.state.towers[tower.id];
      if (level <= 0) continue;
      const animationTooFar = Vector3.Distance(this.player.root.position, tower.root.position) > TOWER_ANIMATION_LOD_DISTANCE;
      if (animationTooFar !== tower.animationLodPaused) {
        tower.animationLodPaused = animationTooFar;
        if (animationTooFar) {
          for (const animation of tower.animations) {
            animation.stop();
            animation.reset();
          }
          tower.currentAnimation = "";
        }
      }
      if (!this.state.waveActive) continue;
      const stats = towerCombatStats(tower.id, level);
      const target = this.findNearestZombie(tower.root.position, stats.range);
      if (!target) continue;
      const delta = target.root.position.subtract(tower.root.position);
      tower.weapon.rotation.y = Math.atan2(delta.x, delta.z);
      if (tower.cooldown > 0) continue;
      tower.cooldown = stats.cooldown;
      if (!tower.animationLodPaused) this.playTowerAnimation(tower, "attack");
      const projectile = this.acquireProjectile(tower.id);
      projectile.position.copyFrom(tower.root.position.add(new Vector3(0, 3.5, 0)));
      this.projectiles.push({
        root: projectile,
        target,
        progress: 0,
        start: projectile.position.clone(),
        source: tower.id,
        damage: stats.damage,
        splash: stats.splash,
        slow: stats.slow,
      });
    }
  }

  private updateProjectiles(dt: number): void {
    for (let index = this.projectiles.length - 1; index >= 0; index -= 1) {
      const projectile = this.projectiles[index];
      if (!projectile.target.alive) {
        this.releaseProjectile(projectile.root, projectile.source);
        this.projectiles.splice(index, 1);
        continue;
      }
      projectile.progress += dt / COMBAT_TIMING.projectileTravelSeconds;
      const targetPosition = projectile.target.root.position.add(new Vector3(0, 1.25, 0));
      projectile.root.position.copyFrom(Vector3.Lerp(projectile.start, targetPosition, Math.min(1, projectile.progress)));
      const direction = targetPosition.subtract(projectile.root.position);
      projectile.root.rotation.y = Math.atan2(direction.x, direction.z);
      projectile.root.position.y += Math.sin(projectile.progress * Math.PI) * 1.4;
      if (projectile.progress < 1) continue;
      const victims = projectile.splash > 0
        ? this.zombies.filter((zombie) => zombie.alive && Vector3.Distance(zombie.root.position, projectile.target.root.position) <= projectile.splash)
        : [projectile.target];
      for (const victim of victims) {
        if (projectile.slow > 0) {
          victim.slowTimer = Math.max(victim.slowTimer, projectile.slow);
          if (addLoopProgress(this.state, "frost-hits")) this.ui.toast(`循環任務完成 · ✦ ${this.state.quest.loop?.reward ?? 0}`, "ice");
        }
        this.damageZombie(victim, projectile.damage, projectile.source);
      }
      if (projectile.source === "cannon") {
        this.createExplosion(projectile.target.root.position, projectile.splash);
        if (victims.length >= 3 && addLoopProgress(this.state, "cannon-combo")) this.ui.toast(`循環任務完成 · ✦ ${this.state.quest.loop?.reward ?? 0}`, "warm");
      }
      this.releaseProjectile(projectile.root, projectile.source);
      this.projectiles.splice(index, 1);
    }
  }

  private acquireProjectile(source: TowerId): TransformNode {
    const pool = this.projectilePools.get(source) ?? [];
    this.projectilePools.set(source, pool);
    const reused = pool.pop();
    if (reused) {
      reused.setEnabled(true);
      reused.rotation.setAll(0);
      return reused;
    }
    if (source === "ballista") {
      const arrow = this.instantiateStatic("tower/arrow.glb", `tower-arrow-pool-${this.elapsed}`, false);
      arrow.scaling.setAll(1.8);
      return arrow;
    }
    const sphere = MeshBuilder.CreateIcoSphere(`${source}-projectile-pool-${this.elapsed}`, { radius: source === "frost" ? 0.23 : 0.38, subdivisions: 1 }, this.scene);
    let material = this.projectileMaterials.get(source);
    if (!material) {
      material = new PBRMaterial(`${source}-projectile-shared-material`, this.scene);
      material.albedoColor = source === "frost" ? new Color3(0.45, 0.88, 1) : new Color3(0.2, 0.16, 0.12);
      material.emissiveColor = source === "frost" ? new Color3(0.16, 0.68, 1) : new Color3(1, 0.24, 0.04);
      material.emissiveIntensity = 1.5;
      material.freeze();
      this.projectileMaterials.set(source, material);
    }
    sphere.material = material;
    return sphere;
  }

  private releaseProjectile(root: TransformNode, source: TowerId): void {
    root.setEnabled(false);
    const pool = this.projectilePools.get(source) ?? [];
    pool.push(root);
    this.projectilePools.set(source, pool);
  }

  private damageZombie(zombie: ZombieActor, damage: number, source: DamageSource): void {
    if (!zombie.alive) return;
    zombie.hp -= damage;
    this.damageEventCount += 1;
    this.lastDamageAt = this.elapsed;
    this.state.stats.damageDealt += damage;
    const vfxEventsBefore = this.vfxEventCount;
    this.triggerGroundImpactVfx(zombie.root.position);
    if (this.visualEvidenceMode && this.vfxEventCount > vfxEventsBefore) {
      this.lastEvidenceEnemyPosition = zombie.root.position.add(new Vector3(0, 1.15, 0));
    }
    this.playAnimation(zombie, "HitReact", false);
    if (source === "player") this.flashZombie(zombie);
    if (zombie.hp <= 0) this.killZombie(zombie, source);
  }

  private killZombie(zombie: ZombieActor, source: DamageSource): void {
    if (!zombie.alive) return;
    zombie.alive = false;
    const deathAnimation = this.playAnimation(zombie, "Death", false, true);
    const deathDuration = this.animationDuration(deathAnimation, 1.35);
    zombie.deathEndsAt = this.elapsed + deathDuration;
    const killReward = zombie.reward + (this.state.customerAffinity.scout_he >= 6 ? 1 : 0);
    creditIncome(this.state, killReward);
    this.state.stats.zombiesKilled += 1;
    let comboBonus = 0;
    if (source === "player") {
      // R23 連斬：2.6 秒內連續親手擊殺，5 連斬起每殺加發 ✦
      const combo = registerComboKill(this.combo, this.elapsed);
      comboBonus = combo.bonus;
      if (comboBonus > 0) creditIncome(this.state, comboBonus);
      this.runBestCombo = Math.max(this.runBestCombo, combo.count);
      this.waveBestCombo = Math.max(this.waveBestCombo, combo.count);
      this.ui.setCombo(combo.count, comboBonus);
    }
    this.showFloater(zombie.root.position.add(new Vector3(0.35, 2.7, 0)), `+✦${killReward + comboBonus}`, "coin");
    if (source === "player") {
      this.state.stats.playerKills += 1;
      this.wavePlayerKills += 1;
      if (addLoopProgress(this.state, "player-kills")) this.ui.toast(`親手清場完成 · ✦ ${this.state.quest.loop?.reward ?? 0}`, "warm");
    } else {
      this.state.stats.towerKills += 1;
      this.waveTowerKills += 1;
      if (addLoopProgress(this.state, "tower-kills")) this.ui.toast(`箭雨校準完成 · ✦ ${this.state.quest.loop?.reward ?? 0}`, "ice");
    }
    this.state.enemiesRemaining = Math.max(0, this.state.enemiesRemaining - 1);
    window.setTimeout(() => zombie.root.setEnabled(false), Math.ceil(deathDuration * 1000) + 34);
  }

  private completeWave(): void {
    if (!this.waveStockLost && addLoopProgress(this.state, "stock-safe")) this.ui.toast(`完整貨架完成 · ✦ ${this.state.quest.loop?.reward ?? 0}`, "warm");
    if (this.state.baseHealth >= 75 && addLoopProgress(this.state, "healthy-wall")) this.ui.toast(`不退防線完成 · ✦ ${this.state.quest.loop?.reward ?? 0}`, "ice");
    this.state.waveActive = false;
    this.state.wave += 1;
    this.state.bestWave = Math.max(this.state.bestWave, this.state.wave);
    this.state.stats.wavesCleared = Math.max(this.state.stats.wavesCleared, this.state.wave);
    this.releaseBait(false);
    if (awardPatrol(this.patrol, this.state.wave, { attracted: this.baitedZombies - this.waveAttractedStart, playerKills: this.wavePlayerKills, wallDamage: this.waveWallDamage })) {
      savePatrol(this.patrol);
      this.ui.toast(`守夜委託達成 · ＋1 守夜章（共 ${this.patrol.completedWaves.length}）· 暫停 → 補給查看解鎖`, "warm");
    }
    const reward = 16 + Math.min(this.state.wave, 10) * 3 + Math.max(0, this.state.wave - 10) + (this.state.wave % 10 === 0 ? 35 : 0) + supplyEffects(this.waveSupply).bonus;
    creditIncome(this.state, reward);
    saveState(this.state);
    this.ui.toast(`第 ${this.state.wave} 波已清除 · 防守獎金 ✦ ${reward}`, "warm");
    {
      const grade = gradeWave({
        wallDamage: this.waveWallDamage,
        playerKills: this.wavePlayerKills,
        totalKills: this.wavePlayerKills + this.waveTowerKills,
        bestCombo: this.waveBestCombo,
        stockLost: this.waveStockLost,
      });
      this.lastWaveGrade = grade;
      this.ui.showWaveReport({
        wave: this.state.wave,
        grade,
        gradeLabel: WAVE_GRADE_LABEL[grade],
        kills: this.wavePlayerKills + this.waveTowerKills,
        playerKills: this.wavePlayerKills,
        bestCombo: this.waveBestCombo,
        wallDamage: Math.round(this.waveWallDamage),
        reward,
      });
    }
    { // R17（辯論裁決 B-01）：北境電台里程碑廣播
      const dispatch = WAVE_DISPATCHES.find((entry) => entry.wave === this.state.wave);
      if (dispatch) window.setTimeout(() => this.ui.toast(dispatch.line, "ice"), 1600);
    }
    this.processQuests();
    const cleared = this.zombies.filter((zombie) => !zombie.alive);
    const recycleDelay = Math.max(0, ...cleared.map((zombie) => zombie.deathEndsAt - this.elapsed)) * 1000 + 80;
    window.setTimeout(() => {
      for (const zombie of cleared) {
        for (const animation of zombie.animations) animation.dispose();
        zombie.root.dispose(false, false);
        const index = this.zombies.indexOf(zombie);
        if (index >= 0) this.zombies.splice(index, 1);
      }
    }, recycleDelay);
    if (this.state.wave >= 30) {
      this.state.stats.campaignWins += 1;
      saveState(this.state);
      window.setTimeout(() => this.finishGame(true), 900);
    }
  }

  private finishGame(won: boolean): void {
    if (this.endShown) return;
    this.endShown = true;
    this.state.waveActive = false;
    if (won) saveState(this.state);
    const minutes = Math.max(1, Math.round((performance.now() - this.campaignStartTime) / 60000));
    // R17（辯論裁決 B-02）：結語依主角分歧（敗北依波數分早/晚兩檔）
    const protagonistDef = PROTAGONISTS.find((entry) => entry.id === this.state.protagonistId);
    const epilogue = protagonistDef
      ? (won ? protagonistDef.victoryLine : (this.state.wave < 10 ? protagonistDef.defeatEarlyLine : protagonistDef.defeatLateLine))
      : "";
    this.ui.showResult(won, (won
      ? `第三十次鐘聲穿過風牆，北境肉舖仍在營業。你成為「北境守望者」。`
      : `肉舖壁壘遭到突破。永久資金、任務、武器、員工與建設都已保留，重新集結後再戰。`) + (epilogue ? `
${epilogue}` : ""), [
      ["守過波次", `${this.state.wave} / 30`],
      ["累計擊殺", `${this.state.stats.zombiesKilled}`],
      ["獵物", `${this.state.stats.cowsKilled}`],
      ["累計總收入", `✦ ${this.state.stats.totalEarned}`],
      ["剩餘資金", `✦ ${this.state.money}`],
      ["本輪時間", `${minutes} 分`],
      ["親手／塔擊殺", `${this.state.stats.playerKills} / ${this.state.stats.towerKills}`],
      ["本局最高連斬", `${this.runBestCombo}`],
      ["壁壘總承傷", `${Math.round(this.state.stats.damageTaken)}`],
      ["丟出誘餌", `${this.baitsThrown}`],
    ], runAdvice({
      won,
      wave: this.state.wave,
      playerKills: this.state.stats.playerKills,
      towerKills: this.state.stats.towerKills,
      damageTaken: this.state.stats.damageTaken,
      baitsThrown: this.baitsThrown,
      bestCombo: this.runBestCombo,
      towersBuilt: Object.values(this.state.towers).filter((level) => level > 0).length,
      maxTowerLevel: Math.max(...Object.values(this.state.towers)),
    }));
  }

  private updateAtmosphere(dt: number): void {
    this.applyWeatherVisualProfile();
    const weather = WEATHER_PROFILES[this.weatherIntensity];
    const targetNight = this.state.waveActive ? 1 : 0;
    this.nightBlend += (targetNight - this.nightBlend) * Math.min(1, dt * 1.15);
    const microCycle = Math.sin(this.elapsed * 0.045) * 0.08;
    const lowQuality = this.state.quality === "低";
    this.sun.intensity = lowQuality
      ? 1.62 - this.nightBlend * 0.82 + microCycle * 0.45
      : 2.35 - this.nightBlend * 1.58 + microCycle;
    this.skyLight.intensity = lowQuality
      ? 0.7 - this.nightBlend * 0.27
      : 1.05 - this.nightBlend * 0.57;
    this.shopLight.intensity = (lowQuality ? 11 : 14) + this.nightBlend * (lowQuality ? 9 : 12);
    this.scene.fogDensity = (lowQuality
      ? 0.0045 + this.nightBlend * 0.003
      : 0.012 + this.nightBlend * 0.008)
      + weather.fogDayAdd + weather.fogNightAdd * this.nightBlend;
    const dayFog = lowQuality ? new Color3(0.065, 0.13, 0.19) : new Color3(0.58, 0.68, 0.72);
    const nightFog = lowQuality ? new Color3(0.025, 0.065, 0.115) : new Color3(0.11, 0.2, 0.29);
    this.scene.fogColor.copyFrom(Color3.Lerp(dayFog, nightFog, this.nightBlend));
    const clear = lowQuality
      ? Color3.Lerp(new Color3(0.045, 0.095, 0.15), new Color3(0.012, 0.035, 0.075), this.nightBlend)
      : Color3.Lerp(new Color3(0.57, 0.69, 0.74), new Color3(0.045, 0.09, 0.16), this.nightBlend);
    this.scene.clearColor.set(clear.r, clear.g, clear.b, 1);
  }

  private updateCamera(dt: number): void {
    const safeFrame = this.resolveCameraSafeFrame();
    const baseTarget = this.player.root.position.add(new Vector3(0, 1.2, 0));
    this.cameraShake *= Math.exp(-dt * 10.5);
    const shake = this.settings.screenShake && this.cameraShake > 0.002
      ? new Vector3(Math.sin(this.elapsed * 73) * this.cameraShake, Math.sin(this.elapsed * 97) * this.cameraShake * 0.35, Math.cos(this.elapsed * 67) * this.cameraShake)
      : Vector3.Zero();
    const target = baseTarget.add(shake);
    this.camera.target.copyFrom(Vector3.Lerp(this.camera.target, target, Math.min(1, dt * 4.8)));
    const baseRadius = this.state.waveActive ? 25 : 19;
    const desiredRadius = baseRadius + safeFrame.portraitBlend * 3;
    this.camera.radius += (desiredRadius - this.camera.radius) * Math.min(1, dt * 1.8);
    const desiredBeta = 1.02 - safeFrame.portraitBlend * 0.2;
    this.camera.beta += (desiredBeta - this.camera.beta) * Math.min(1, dt * 3.6);
    const safeCenterY = (safeFrame.top + safeFrame.bottom) / 2;
    const canvasCenterY = safeFrame.canvasTop + safeFrame.height / 2;
    const verticalWorldSpan = 2 * desiredRadius * Math.tan(this.camera.fov / 2);
    const desiredScreenOffsetY = safeFrame.portraitBlend
      * Math.max(0, canvasCenterY - safeCenterY)
      * verticalWorldSpan / Math.max(1, safeFrame.height);
    this.camera.targetScreenOffset.y += (desiredScreenOffsetY - this.camera.targetScreenOffset.y) * Math.min(1, dt * 4.8);
    this.snowEmitter.position.copyFrom(this.camera.target.add(new Vector3(-2, 10, 0)));
  }

  private resolveCameraSafeFrame(): CameraSafeFrame {
    const canvas = this.engine.getRenderingCanvas();
    if (!canvas) return { width: 1, height: 1, canvasTop: 0, left: 0, right: 1, top: 0, bottom: 1, portraitBlend: 0 };
    const bounds = canvas.getBoundingClientRect();
    if (this.cameraSafeFrame?.width === bounds.width && this.cameraSafeFrame.height === bounds.height) return this.cameraSafeFrame;

    const aspect = bounds.width / Math.max(1, bounds.height);
    // R19（SA-R1-01）：只在手機級極窄直向漸入；768×1024 平板、橫向與桌機維持 R18 framing。
    const portraitBlend = Math.max(0, Math.min(1, (0.72 - aspect) / 0.16));
    const topHud = document.querySelector<HTMLElement>(".hud--top")?.getBoundingClientRect();
    const bottomControls = document.querySelector<HTMLElement>(".bottom-controls")?.getBoundingClientRect();
    const top = portraitBlend > 0 && topHud
      ? Math.max(bounds.top + 12, topHud.bottom + 12)
      : bounds.top + 12;
    const bottom = portraitBlend > 0 && bottomControls
      ? Math.min(bounds.bottom - 12, bottomControls.top - 12)
      : bounds.bottom - 12;
    this.cameraSafeFrame = {
      width: bounds.width,
      height: bounds.height,
      canvasTop: bounds.top,
      left: bounds.left + 12,
      right: bounds.right - 12,
      top,
      bottom: Math.max(top + 1, bottom),
      portraitBlend,
    };
    return this.cameraSafeFrame;
  }

  private playerFramingSnapshot(): unknown {
    if (!this.player) return null;
    const canvas = this.engine.getRenderingCanvas();
    if (!canvas) return null;
    const bounds = canvas.getBoundingClientRect();
    const safe = this.resolveCameraSafeFrame();
    const points = this.player.root.getChildMeshes(false)
      .filter((mesh) => mesh.isEnabled() && mesh.getTotalVertices() > 0 && !mesh.name.endsWith("-blob-shadow"))
      .flatMap((mesh) => {
        mesh.computeWorldMatrix(true);
        return mesh.getBoundingInfo().boundingBox.vectorsWorld.map((point) => this.worldPositionScreenPoint(point));
      })
      .filter((point): point is { x: number; y: number } => point !== null && Number.isFinite(point.x) && Number.isFinite(point.y));
    if (!points.length) return null;
    const playerBounds = {
      left: Math.min(...points.map((point) => point.x)),
      right: Math.max(...points.map((point) => point.x)),
      top: Math.min(...points.map((point) => point.y)),
      bottom: Math.max(...points.map((point) => point.y)),
    };
    const playerAnchor = this.worldPositionScreenPoint(this.player.root.position.add(new Vector3(0, 1.15, 0)));
    const forward = this.player.meshForwardNode.getDirection(this.player.meshForwardAxis).normalize();
    const attackDirection = this.worldPositionScreenPoint(this.player.root.position.add(forward.scale(2.6)).add(new Vector3(0, 1.15, 0)));
    const sampleFractions = [
      [0.5, 0.2], [0.35, 0.38], [0.5, 0.38], [0.65, 0.38],
      [0.4, 0.56], [0.5, 0.56], [0.6, 0.56], [0.42, 0.76], [0.58, 0.76],
    ];
    const occluders = new Set<string>();
    let visibleSamples = 0;
    for (const [xFraction, yFraction] of sampleFractions) {
      const cssX = playerBounds.left + (playerBounds.right - playerBounds.left) * xFraction;
      const cssY = playerBounds.top + (playerBounds.bottom - playerBounds.top) * yFraction;
      // Scene.pick consumes canvas CSS coordinates and applies the engine's
      // hardware scaling internally; pre-scaling here would sample the wrong quadrant.
      // R23：已淡化到 28% 的遮擋物不再算遮擋（玩家看得到後方角色）
      const picked = this.scene.pick(cssX - bounds.left, cssY - bounds.top, (mesh) => mesh.isPickable && mesh.isVisible && mesh.isEnabled() && !this.fadedOccluders.has(mesh), false, this.camera)?.pickedMesh ?? null;
      let node: TransformNode | AbstractMesh | null = picked;
      let belongsToPlayer = false;
      while (node) {
        if (node === this.player.root) {
          belongsToPlayer = true;
          break;
        }
        node = node.parent as TransformNode | AbstractMesh | null;
      }
      if (belongsToPlayer) visibleSamples += 1;
      else if (picked) occluders.add(picked.name);
    }
    const directionPixels = playerAnchor && attackDirection
      ? Math.hypot(attackDirection.x - playerAnchor.x, attackDirection.y - playerAnchor.y)
      : 0;
    return {
      viewport: { width: bounds.width, height: bounds.height },
      profile: safe.portraitBlend > 0 ? "narrow-portrait" : "standard",
      safeFrame: { left: safe.left, right: safe.right, top: safe.top, bottom: safe.bottom },
      playerBounds,
      playerAnchor,
      attackDirection,
      directionPixels,
      visibleSamples,
      sampleCount: sampleFractions.length,
      occluders: [...occluders].slice(0, 6),
      camera: {
        beta: this.camera.beta,
        radius: this.camera.radius,
        targetScreenOffsetY: this.camera.targetScreenOffset.y,
      },
    };
  }

  private kickCameraShake(amount: number): void {
    if (!this.settings.screenShake) return;
    this.cameraShake = Math.max(this.cameraShake, amount);
  }

  private processQuests(): void {
    const completions = updateMainQuests(this.state);
    for (const [index, completion] of completions.entries()) {
      window.setTimeout(() => this.ui.completeQuest(completion), index * 820);
    }
  }

  private updateContextPrompt(): void {
    const attackKey = this.ui.touchMode ? "揮砍鈕" : "SPACE";
    if (this.state.waveActive && this.findNearestZombie(this.player.root.position, 3.1)) {
      this.ui.setPrompt(attackKey, "攻擊殭屍", true);
    } else if (this.findNearestCow(this.player.root.position, 3.3)) {
      this.ui.setPrompt(attackKey, `${this.state.weapon === "smg" ? "掃射" : this.state.weapon === "axe" ? "橫掃" : "揮砍"}牛隻`, true);
    } else if (this.state.carriedMeat > 0 && Vector3.Distance(this.player.root.position, STALL_POSITION) < 5) {
      this.ui.setPrompt("AUTO", "靠近攤位自動陳列", true);
    } else if (this.state.towers.ballista === 0 && Vector3.Distance(this.player.root.position, TOWER_POSITIONS.ballista) < 4) {
      const unlocked = hasCompletedChapter(this.state, SHOP_UNLOCK_CHAPTER.defenseShop);
      this.ui.setPrompt(this.ui.touchMode ? "整備" : "B", unlocked ? `建造獵風弩塔 · ✦ ${towerCostForState(this.state, "ballista", 0)}` : "完成手冊第 5 章解鎖防線", true);
    } else {
      this.ui.setPrompt(this.ui.touchMode ? "搖桿" : "WASD", this.ui.touchMode ? "虛擬搖桿移動 · 揮砍鈕攻擊" : "穿越雪地 · 空白鍵揮砍", true);
    }
  }

  private requireChapter(chapter: number): boolean {
    if (hasCompletedChapter(this.state, chapter)) return true;
    this.ui.toast(`🔒 完成手冊第 ${chapter} 章解鎖`, "ice");
    return false;
  }

  private instantiateActor(file: string, name: string, position: Vector3, scale: number): Actor {
    const container = this.assets.get(file)!;
    const entries = container.instantiateModelsToScene((source) => `${name}-${source}`, false, { doNotInstantiate: false });
    const root = new TransformNode(name, this.scene);
    for (const node of entries.rootNodes) node.parent = root;
    root.position.copyFrom(position);
    root.scaling.setAll(scale);
    const meshForwardNode = root.getChildTransformNodes(false).find((node) =>
      node.name.includes("Protagonist") || node.name.includes("Npc"),
    ) ?? root;
    const meshForwardAxis = file.startsWith("custom/characters/")
      || file.startsWith("custom/zombies/")
      || file.startsWith("custom/world/cow-")
      || file === "custom/boss-zombie.glb"
      ? Vector3.Backward()
      : Vector3.Forward();
    return { root, meshForwardNode, meshForwardAxis, animations: entries.animationGroups, currentAnimation: "" };
  }

  private replacePlayerModel(): void {
    const previous = this.player;
    const definition = PROTAGONISTS.find((entry) => entry.id === this.state.protagonistId)!;
    const replacement = this.instantiateActor(definition.model, `player-${definition.id}`, previous.root.position.clone(), 1);
    replacement.root.rotation.copyFrom(previous.root.rotation);
    this.weaponModel?.dispose(false, false);
    this.weaponModel = undefined;
    this.muzzleFlash = undefined;
    for (const visual of this.carriedVisuals) visual.parent = replacement.root;
    for (const animation of previous.animations) animation.dispose();
    previous.root.dispose(false, false);
    this.player = replacement;
    this.playAnimation(this.player, "idle", true);
    this.createWeaponModel();
    this.addActorShadows(this.player);
  }

  private instantiateStatic(file: string, name: string, freezeEligible = true): TransformNode {
    const container = this.assets.get(file)!;
    const batchByMaterial = STATIC_MATERIAL_BATCH_FILES.has(file);
    const entries = container.instantiateModelsToScene((source) => `${name}-${source}`, false, { doNotInstantiate: batchByMaterial });
    const root = new TransformNode(name, this.scene);
    for (const node of entries.rootNodes) node.parent = root;
    if (batchByMaterial) {
      const groups = new Map<number, Mesh[]>();
      for (const mesh of root.getChildMeshes()) {
        if (!(mesh instanceof Mesh) || mesh.getTotalVertices() === 0 || !mesh.material) continue;
        const group = groups.get(mesh.material.uniqueId) ?? [];
        group.push(mesh);
        groups.set(mesh.material.uniqueId, group);
      }
      let batchIndex = 0;
      for (const meshes of groups.values()) {
        if (meshes.length < 2) continue;
        for (const mesh of meshes) mesh.computeWorldMatrix(true);
        const merged = Mesh.MergeMeshes(meshes, true, true, undefined, false, true);
        if (!merged) continue;
        merged.name = `${name}-material-batch-${batchIndex}`;
        merged.parent = root;
        batchIndex += 1;
      }
    }
    for (const mesh of root.getChildMeshes()) this.castShadows(mesh);
    root.metadata = { ...(root.metadata ?? {}), stormStatic: freezeEligible };
    return root;
  }

  private freezeStaticScene(): void {
    let frozenMeshes = 0;
    for (const node of this.scene.transformNodes) {
      if (!node.metadata?.stormStatic) continue;
      for (const mesh of node.getChildMeshes()) {
        mesh.freezeWorldMatrix();
        frozenMeshes += 1;
      }
    }
    for (const material of this.scene.materials) {
      if (!material.name.includes("attack-ring") && !material.name.includes("blast")) material.freeze();
    }
    (window as Window & { __stormOptimization?: unknown }).__stormOptimization = {
      staticMeshesFrozen: frozenMeshes,
      instancedMeshes: this.scene.meshes.filter((mesh) => mesh.getClassName() === "InstancedMesh").length,
      materials: this.scene.materials.length,
      deduplicatedMaterials: this.deduplicatedMaterials,
      textureTier: this.state.quality,
    };
  }

  private deduplicateAssetMaterials(): void {
    const canonical = new Map<string, NonNullable<AbstractMesh["material"]>>();
    for (const container of this.assets.values()) {
      for (const mesh of container.meshes) {
        const material = mesh.material;
        if (!material) continue;
        // Different GLBs can reuse a texture display name while pointing at a
        // different source/internal texture (for example both texture packs
        // call their atlas "colormap"). Only deduplicate texture-free authored
        // materials; Babylon already shares each compatible loaded texture.
        if (material.getActiveTextures().length > 0) continue;
        const pbr = material as PBRMaterial;
        const key = [
          material.getClassName(),
          material.name.replace(/\.\d{3}$/u, ""),
          pbr.albedoColor?.toHexString() ?? "",
          pbr.metallic ?? "",
          pbr.roughness ?? "",
        ].join("|");
        const shared = canonical.get(key);
        if (shared && shared !== material) {
          mesh.material = shared;
          this.deduplicatedMaterials += 1;
        } else {
          canonical.set(key, material);
        }
      }
    }
  }

  private playAnimation(actor: Actor, name: string, loop: boolean, restart = false): AnimationGroup | undefined {
    if (actor.currentAnimation === name && !restart) return actor.animations.find((animation) => animation.name === name);
    for (const animation of actor.animations) animation.stop();
    const selected = actor.animations.find((animation) => animation.name === name)
      ?? actor.animations.find((animation) => animation.name.toLowerCase().includes(name.toLowerCase()));
    if (!selected) return undefined;
    selected.reset();
    selected.play(loop);
    if ("animationLodPaused" in actor) actor.animationLodPaused = false;
    actor.currentAnimation = name;
    if (!loop) {
      selected.onAnimationGroupEndObservable.addOnce(() => {
        if (actor.currentAnimation === name && actor.root.isEnabled()) {
          if (name.toLowerCase().includes("death")) {
            actor.currentAnimation = "death-complete";
            return;
          }
          actor.currentAnimation = "";
          this.playAnimation(actor, "idle", true);
        }
      });
    }
    return selected;
  }

  private isAttackAnimation(actor: Actor): boolean {
    return actor.currentAnimation.startsWith("attack_");
  }

  private animationDuration(animation: AnimationGroup | undefined, fallback: number): number {
    if (!animation) return fallback;
    const fps = animation.targetedAnimations[0]?.animation.framePerSecond ?? 24;
    return Math.max(0.1, (animation.to - animation.from) / Math.max(1, fps));
  }

  private playTowerAnimation(tower: TowerActor, name: string): void {
    for (const animation of tower.animations) animation.stop();
    const selected = tower.animations.find((animation) => animation.name === name)
      ?? tower.animations.find((animation) => animation.name.toLowerCase().includes(name.toLowerCase()));
    if (!selected) return;
    selected.reset();
    selected.play(false);
    tower.currentAnimation = name;
    selected.onAnimationGroupEndObservable.addOnce(() => {
      if (tower.currentAnimation === name) tower.currentAnimation = "";
    });
  }

  private addActorShadows(actor: Actor): void {
    if (!this.shadows || this.blobShadowsActive) {
      this.createBlobShadow(actor.root);
      return;
    }
    for (const mesh of actor.root.getChildMeshes()) this.castShadows(mesh);
  }

  private createBlobShadow(root: TransformNode): void {
    const existing = root.getChildMeshes().find((mesh) => mesh.name === `${root.name}-blob-shadow`);
    if (existing) {
      existing.setEnabled(true);
      return;
    }
    if (!this.blobShadowMaterial) {
      const material = new StandardMaterial("mobile-blob-shadow-material", this.scene);
      material.diffuseColor = Color3.Black();
      material.emissiveColor = new Color3(0.008, 0.015, 0.022);
      material.specularColor = Color3.Black();
      material.alpha = 0.24;
      material.disableLighting = true;
      material.backFaceCulling = false;
      this.blobShadowMaterial = material;
    }
    if (!this.blobShadowSource) {
      const source = MeshBuilder.CreateDisc("shared-blob-shadow", { radius: 1, tessellation: 12 }, this.scene);
      source.position.y = -1000;
      source.rotation.x = Math.PI / 2;
      source.material = this.blobShadowMaterial;
      source.isPickable = false;
      source.receiveShadows = false;
      this.blobShadowSource = source;
    }
    this.blobShadowSource.setEnabled(true);
    const radius = root.name.includes("cow") || root.name.includes("boss")
      ? 1.08
      : root.name.includes("dog")
        ? 0.72
        : 0.62;
    const blob = this.blobShadowSource.createInstance(`${root.name}-blob-shadow`);
    const inverseScale = 1 / Math.max(0.01, root.scaling.x);
    blob.parent = root;
    blob.position.y = 0.035 * inverseScale;
    blob.rotation.x = Math.PI / 2;
    blob.scaling.setAll(radius * inverseScale);
    blob.isPickable = false;
    blob.receiveShadows = false;
  }

  private castShadows(mesh: AbstractMesh): void {
    if (!this.shadows || this.blobShadowsActive) {
      mesh.receiveShadows = false;
      return;
    }
    if (mesh.getClassName() !== "InstancedMesh") mesh.receiveShadows = true;
    this.shadows.addShadowCaster(mesh, true);
  }

  private moveActorToward(actor: Actor, destination: Vector3, speed: number, dt: number): boolean {
    const delta = destination.subtract(actor.root.position);
    delta.y = 0;
    const distance = delta.length();
    if (distance < 0.12) return true;
    const direction = delta.normalize();
    actor.root.position.addInPlace(direction.scale(Math.min(distance, speed * dt)));
    actor.root.position.y = this.heightAt(actor.root.position.x, actor.root.position.z);
    actor.root.rotation.y = this.lerpAngle(actor.root.rotation.y, Math.atan2(direction.x, direction.z), Math.min(1, dt * 8));
    return distance < 0.2;
  }

  private createMeatPiece(name: string, scale: number): TransformNode {
    const root = this.instantiateStatic("custom/meat-slice.glb", name, false);
    root.scaling.setAll(scale);
    return root;
  }

  private updateMeatVisuals(): void {
    this.carriedVisuals.forEach((visual, index) => visual.setEnabled(index < this.state.carriedMeat));
    this.stockVisuals.forEach((visual, index) => visual.setEnabled(index < this.state.displayedMeat));
  }

  private createWorldRing(name: string, position: Vector3, diameter: number, color: Color3): Mesh {
    const ring = MeshBuilder.CreateTorus(name, { diameter, thickness: 0.055, tessellation: 64 }, this.scene);
    ring.position.set(position.x, this.heightAt(position.x, position.z) + 0.11, position.z);
    const material = new PBRMaterial(`${name}-material`, this.scene);
    material.albedoColor = color;
    material.emissiveColor = color;
    material.emissiveIntensity = 1.2;
    material.roughness = 0.4;
    ring.material = material;
    return ring;
  }

  private createCampfire(position: Vector3): void {
    const stones = this.instantiateStatic("campfire-stones.glb", "shop-campfire-stones");
    stones.position.set(position.x, this.heightAt(position.x, position.z), position.z);
    stones.scaling.setAll(1.5);
    const fireLight = new PointLight("campfire-light", new Vector3(position.x, stones.position.y + 1, position.z), this.scene);
    fireLight.diffuse = new Color3(1, 0.33, 0.08);
    fireLight.intensity = 8;
    fireLight.range = 8;
    const flame = new DynamicTexture("flame-particle", 24, this.scene, false);
    const context = flame.getContext() as unknown as CanvasRenderingContext2D;
    const gradient = context.createRadialGradient(12, 12, 1, 12, 12, 11);
    gradient.addColorStop(0, "rgba(255,245,180,1)");
    gradient.addColorStop(0.35, "rgba(255,125,30,.95)");
    gradient.addColorStop(1, "rgba(180,20,0,0)");
    context.fillStyle = gradient;
    context.fillRect(0, 0, 24, 24);
    flame.hasAlpha = true;
    flame.update();
    const particles = new ParticleSystem("campfire-flames", this.state.quality === "低" ? 40 : this.state.quality === "中" ? 90 : 140, this.scene);
    this.ambientParticles.push(particles);
    particles.particleTexture = flame;
    particles.emitter = fireLight.position;
    particles.minEmitBox = new Vector3(-0.2, 0, -0.2);
    particles.maxEmitBox = new Vector3(0.2, 0.15, 0.2);
    particles.color1 = new Color4(1, 0.36, 0.05, 1);
    particles.color2 = new Color4(1, 0.8, 0.2, 0.8);
    particles.minSize = 0.12;
    particles.maxSize = 0.38;
    particles.minLifeTime = 0.22;
    particles.maxLifeTime = 0.62;
    particles.emitRate = this.state.quality === "低" ? 24 : this.state.quality === "中" ? 58 : 90;
    particles.direction1 = new Vector3(-0.15, 1.2, -0.15);
    particles.direction2 = new Vector3(0.15, 2.1, 0.15);
    particles.gravity = new Vector3(0, 1, 0);
    particles.blendMode = ParticleSystem.BLENDMODE_ADD;
    particles.start();
  }

  private createWeaponModel(): void {
    this.weaponModel?.dispose(false, false);
    this.muzzleFlash = undefined;
    const socket = this.player.root.getChildTransformNodes(false).find((node) => node.name.includes("WeaponSocket"));
    if (this.state.protagonistId === "butcher_matron" && this.state.weapon === "machete") {
      // Her authored cleaver is already bound to hand.R and carries the full melee arc.
      const root = new TransformNode("player-weapon-authored-cleaver", this.scene);
      root.parent = socket ?? this.player.root;
      root.setEnabled(false);
      this.weaponModel = root;
      return;
    }
    const root = this.instantiateStatic(`custom/weapons/${this.state.weapon}.glb`, `player-weapon-${this.state.weapon}`, false);
    root.parent = socket ?? this.player.root;
    root.position.set(socket ? 0 : 0.52, socket ? 0 : 1.18, socket ? 0 : 0.24);
    root.rotation.set(0.12, 0, -0.18);
    root.scaling.setAll(this.state.weapon === "smg" ? 0.82 : 0.88);
    if (this.state.weapon === "smg") {
      const flash = MeshBuilder.CreateIcoSphere("smg-muzzle-flash", { radius: 0.24, subdivisions: 1 }, this.scene);
      flash.parent = root;
      flash.position.y = 1.92;
      const flashMaterial = new PBRMaterial("smg-muzzle-flash-material", this.scene);
      flashMaterial.albedoColor = new Color3(1, 0.62, 0.08);
      flashMaterial.emissiveColor = new Color3(1, 0.18, 0.01);
      flashMaterial.emissiveIntensity = 2;
      flash.material = flashMaterial;
      flash.setEnabled(false);
      this.muzzleFlash = flash;
    }
    this.weaponModel = root;
  }

  // ===== R23：打擊回饋／連斬／誘餌／信標／遮擋淡化 =====
  private showFloater(position: Vector3, text: string, kind: "hit" | "crit" | "coin" | "miss" | "info"): void {
    const point = this.worldPositionScreenPoint(position);
    if (!point) return;
    this.floaterCount += 1;
    this.ui.floater(point.x, point.y, text, kind);
  }

  private flashZombie(zombie: ZombieActor): void {
    for (const mesh of zombie.root.getChildMeshes(false)) {
      if (mesh.getClassName() === "InstancedMesh") continue;
      mesh.renderOverlay = true;
      mesh.overlayColor = Color3.White();
      mesh.overlayAlpha = 0.55;
    }
    zombie.flashUntil = this.elapsed + 0.09;
    if (!this.flashingZombies.includes(zombie)) this.flashingZombies.push(zombie);
    this.hitFlashes += 1;
  }

  private throwBait(target?: Vector3): void {
    if (!this.started || this.endShown || this.paused) return;
    if (!this.state.waveActive) {
      this.ui.toast("誘餌只在夜襲時使用：把屍群拉進塔的射界。", "ice");
      return;
    }
    if (this.baitCooldown > 0) {
      this.showFloater(this.player.root.position.add(new Vector3(0, 2.4, 0)), `誘餌冷卻 ${Math.ceil(this.baitCooldown)} 秒`, "info");
      return;
    }
    const source = pickBaitSource(this.state.carriedMeat, this.state.displayedMeat, this.baitScraps);
    if (!source) {
      this.ui.toast("背包和攤位都沒有肉，無法丟誘餌。白天多狩獵一些吧。", "danger");
      return;
    }
    if (source === "scraps") this.baitScraps -= 1;
    else if (source === "carried") this.state.carriedMeat -= 1;
    else this.state.displayedMeat -= 1;
    this.updateMeatVisuals();
    this.disposeBait();
    const forward = this.player.meshForwardNode.getDirection(this.player.meshForwardAxis);
    forward.y = 0;
    if (forward.lengthSquared() < 0.01) forward.set(0, 0, 1);
    forward.normalize();
    const position = target?.clone() ?? this.player.root.position.add(forward.scale(BAIT_RULES.throwDistance));
    position.x = Math.max(-24, Math.min(24, position.x));
    position.z = Math.max(-20, Math.min(20, position.z));
    position.y = this.heightAt(position.x, position.z);
    const root = this.createMeatPiece(`meat-bait-${this.elapsed}`, 0.85);
    root.position.set(position.x, position.y + 0.35, position.z);
    root.rotation.set(0.2, 0, Math.PI / 2);
    const ring = this.createWorldRing(`meat-bait-ring-${this.elapsed}`, position, BAIT_RULES.radius * 2, new Color3(0.95, 0.32, 0.22));
    ring.isPickable = false;
    this.bait = { root, ring, position, expiresAt: this.elapsed + BAIT_RULES.lifetime };
    this.baitCooldown = BAIT_RULES.cooldown;
    this.baitsThrown += 1;
    const attracted = this.attractToBait();
    this.audio.play("bait");
    this.kickCameraShake(0.06);
    this.showFloater(position.add(new Vector3(0, 1.6, 0)), attracted > 0 ? `誘餌 · 引來 ${attracted} 隻` : "誘餌落地", "info");
    saveState(this.state);
  }

  private attractToBait(): number {
    if (!this.bait) return 0;
    const bait = this.bait;
    const living = this.zombies.map((zombie) => ({ type: zombie.type, alive: zombie.alive && zombie.baitUntil < bait.expiresAt, x: zombie.root.position.x, z: zombie.root.position.z }));
    const indices = baitAttractedIndices({ x: bait.position.x, z: bait.position.z }, living);
    for (const index of indices) this.zombies[index].baitUntil = bait.expiresAt;
    this.baitedZombies += indices.length;
    return indices.length;
  }

  private disposeBait(): void {
    if (!this.bait) return;
    this.bait.root.dispose(false, false);
    this.bait.ring.material?.dispose();
    this.bait.ring.dispose(false, true);
    this.bait = undefined;
  }

  private updateR23Feedback(dt: number): void {
    if (this.baitAimPosition) this.ui.setBaitAimPoint(this.worldPositionScreenPoint(this.baitAimPosition));
    this.baitCooldown = Math.max(0, this.baitCooldown - dt);
    if (comboExpired(this.combo, this.elapsed)) {
      this.combo.count = 0;
      this.ui.setCombo(0, 0);
    }
    if (this.flashingZombies.length > 0) {
      this.flashingZombies = this.flashingZombies.filter((zombie) => {
        if (zombie.flashUntil > this.elapsed && zombie.alive) return true;
        for (const mesh of zombie.root.getChildMeshes(false)) mesh.renderOverlay = false;
        return false;
      });
    }
    if (this.bait) {
      if (!this.state.waveActive || this.elapsed >= this.bait.expiresAt) this.disposeBait();
      else {
        const life = (this.bait.expiresAt - this.elapsed) / BAIT_RULES.lifetime;
        const pulse = 0.92 + Math.sin(this.elapsed * 7) * 0.05;
        this.bait.ring.scaling.set(pulse * (0.55 + life * 0.45), 1, pulse * (0.55 + life * 0.45));
        this.bait.root.rotation.y += dt * 1.8;
        this.attractToBait();
      }
    }
    this.ui.setBaitState({
      visible: this.started && this.state.waveActive,
      cooldown: this.baitCooldown / BAIT_RULES.cooldown,
      meat: this.baitScraps + this.state.carriedMeat + this.state.displayedMeat,
    });
    if (this.started) this.audio.setMusicMode(this.endShown ? "off" : this.state.waveActive ? "night" : "day");
    this.updateBeacon();
    this.occlusionTimer -= dt;
    if (this.occlusionTimer <= 0) {
      this.occlusionTimer = 0.15;
      this.updateOcclusionFade();
    }
  }

  private beaconTargetPosition(): { id: string; position: Vector3 | null } {
    if (!this.started || this.endShown || this.state.waveActive || this.state.wave >= 3) return { id: "none", position: null };
    if (this.state.carriedMeat >= 6) return { id: "stall", position: STALL_POSITION };
    const drop = this.drops
      .slice()
      .sort((left, right) => Vector3.DistanceSquared(left.root.position, this.player.root.position) - Vector3.DistanceSquared(right.root.position, this.player.root.position))[0];
    if (drop) return { id: "meat", position: drop.root.position };
    if (this.state.carriedMeat > 0) return { id: "stall", position: STALL_POSITION };
    const chapter = this.state.quest.chapter;
    const hasTower = Object.values(this.state.towers).some((level) => level > 0);
    const defenseUnlocked = hasCompletedChapter(this.state, SHOP_UNLOCK_CHAPTER.defenseShop);
    if (defenseUnlocked && !hasTower && this.state.money >= towerCostForState(this.state, "ballista", 0)) return { id: "tower", position: TOWER_POSITIONS.ballista };
    if (chapter <= 6 && this.cow.alive && this.state.displayedMeat < 3) return { id: "cow", position: this.cow.root.position };
    return { id: "none", position: null };
  }

  private ensureBeacon(): TransformNode {
    if (this.beacon) return this.beacon;
    const root = new TransformNode("r23-objective-beacon", this.scene);
    const material = new StandardMaterial("r23-beacon-material", this.scene);
    material.emissiveColor = new Color3(1, 0.72, 0.32);
    material.diffuseColor = Color3.Black();
    material.disableLighting = true;
    material.alpha = 0.32;
    material.backFaceCulling = false;
    const pillar = MeshBuilder.CreateCylinder("r23-beacon-pillar", { height: 7, diameterTop: 0.18, diameterBottom: 0.75, tessellation: 18 }, this.scene);
    pillar.position.y = 3.5;
    pillar.material = material;
    pillar.isPickable = false;
    pillar.parent = root;
    const arrowMaterial = material.clone("r23-beacon-arrow-material");
    arrowMaterial.alpha = 0.95;
    const arrow = MeshBuilder.CreateCylinder("r23-beacon-arrow", { height: 0.7, diameterTop: 0.62, diameterBottom: 0, tessellation: 4 }, this.scene);
    arrow.position.y = 2.6;
    arrow.material = arrowMaterial;
    arrow.isPickable = false;
    arrow.parent = root;
    root.setEnabled(false);
    this.beacon = root;
    return root;
  }

  private updateBeacon(): void {
    const target = this.beaconTargetPosition();
    this.beaconTarget = target.id;
    if (!target.position) {
      if (this.beacon) this.beacon.setEnabled(false);
      return;
    }
    const beacon = this.ensureBeacon();
    beacon.setEnabled(true);
    beacon.position.set(target.position.x, this.heightAt(target.position.x, target.position.z), target.position.z);
    const arrow = beacon.getChildMeshes(true).find((mesh) => mesh.name === "r23-beacon-arrow");
    if (arrow) {
      arrow.position.y = 2.6 + Math.sin(this.elapsed * 3.2) * 0.25;
      arrow.rotation.y += 0.04;
    }
  }

  private isOccluderCandidate(mesh: AbstractMesh): boolean {
    if (!mesh.isEnabled() || /wind-carved-snow|snow-path|zombie|cow|customer|staff|blob-shadow|ring|decal|vfx|beacon|bait|meat/u.test(mesh.name)) return false;
    let node: TransformNode | AbstractMesh | null = mesh;
    while (node) {
      if (node === this.player.root) return false;
      node = node.parent as TransformNode | AbstractMesh | null;
    }
    return true;
  }

  private refreshOccluderCandidates(): void {
    // 只快取一次靜態場景候選（圍欄、樹、房屋、塔…），避免每次對全場 ~1000 個網格做射線檢查
    this.occluderCandidates = this.scene.meshes.filter((mesh) => mesh.isPickable && mesh.getTotalVertices() > 0 && this.isOccluderCandidate(mesh));
    this.occluderCandidatesAt = this.elapsed;
  }

  private updateOcclusionFade(): void {
    if (!this.player || !this.started) return;
    if (this.occluderCandidates.length === 0 || this.elapsed - this.occluderCandidatesAt > 8) this.refreshOccluderCandidates();
    const occluding = new Set<AbstractMesh>();
    const view = this.player.root.position.subtract(this.camera.position);
    const side = Vector3.Cross(view, Vector3.Up()).normalize().scale(0.32);
    for (const [height, lateral] of [[0.35, 0], [0.85, 0], [1.35, 0], [0.85, 1], [0.85, -1]] as const) {
      const target = this.player.root.position.add(new Vector3(0, height, 0)).add(side.scale(lateral));
      const direction = target.subtract(this.camera.position);
      const length = direction.length();
      const ray = new Ray(this.camera.position, direction.normalize(), length - 0.35);
      for (const mesh of this.occluderCandidates) {
        if (occluding.has(mesh) || !mesh.isEnabled()) continue;
        const box = mesh.getBoundingInfo().boundingBox;
        if (!ray.intersectsBoxMinMax(box.minimumWorld, box.maximumWorld)) continue;
        if (!ray.intersectsMesh(mesh as Mesh, true).hit) continue;
        occluding.add(mesh);
        // 同一件道具（圍欄段、樹、房屋）的所有子網格一起淡化，避免只透明一層材質
        let top: TransformNode | AbstractMesh = mesh;
        while (top.parent) top = top.parent as TransformNode | AbstractMesh;
        if (top !== mesh) {
          const group = top.getChildMeshes(false);
          if (group.length <= 48) for (const child of group) if (this.occluderCandidates.includes(child)) occluding.add(child);
        }
      }
    }
    for (const mesh of this.fadedOccluders) {
      if (occluding.has(mesh)) continue;
      if (mesh.getClassName() === "InstancedMesh") mesh.isVisible = true;
      else mesh.visibility = 1;
      this.fadedOccluders.delete(mesh);
    }
    for (const mesh of occluding) {
      if (this.fadedOccluders.has(mesh)) continue;
      if (mesh.getClassName() === "InstancedMesh") mesh.isVisible = false;
      else mesh.visibility = 0.28;
      // 保留可點選（塔、圍欄的世界操作仍可用）；可讀性判讀改由 fadedOccluders 排除
      this.fadedOccluders.add(mesh);
    }
  }

  private createAttackRing(color: Color3, position = this.player.root.position): void {
    const ring = MeshBuilder.CreateTorus(`attack-ring-${this.elapsed}`, { diameter: 2.2, thickness: 0.08, tessellation: 32 }, this.scene);
    ring.position.set(position.x, this.heightAt(position.x, position.z) + 0.15, position.z);
    const material = new PBRMaterial(`attack-ring-material-${this.elapsed}`, this.scene);
    material.albedoColor = color;
    material.emissiveColor = color;
    material.emissiveIntensity = 1.2;
    material.alpha = 0.8;
    ring.material = material;
    let progress = 0;
    const animate = (): void => {
      progress += 0.12;
      ring.scaling.setAll(1 + progress * 2.4);
      material.alpha = Math.max(0, 0.8 - progress);
      if (progress < 0.85) requestAnimationFrame(animate);
      else ring.dispose(false, true);
    };
    animate();
  }

  private createExplosion(position: Vector3, radius: number): void {
    const blast = MeshBuilder.CreateIcoSphere(`cannon-blast-${this.elapsed}`, { radius: 0.5, subdivisions: 2 }, this.scene);
    blast.position.set(position.x, this.heightAt(position.x, position.z) + 0.8, position.z);
    const material = new PBRMaterial(`cannon-blast-material-${this.elapsed}`, this.scene);
    material.albedoColor = new Color3(1, 0.24, 0.03);
    material.emissiveColor = new Color3(1, 0.08, 0.01);
    material.emissiveIntensity = 2.5;
    material.alpha = 0.82;
    blast.material = material;
    const light = new PointLight(`cannon-blast-light-${this.elapsed}`, blast.position.clone(), this.scene);
    light.diffuse = new Color3(1, 0.24, 0.04);
    light.intensity = this.state.quality === "低" ? 0 : 12;
    light.range = radius * 2.2;
    let progress = 0;
    const animate = (): void => {
      progress += 0.15;
      blast.scaling.setAll(1 + progress * radius);
      material.alpha = Math.max(0, 0.82 - progress);
      light.intensity *= 0.62;
      if (progress < 0.9) requestAnimationFrame(animate);
      else {
        blast.dispose(false, true);
        light.dispose();
      }
    };
    animate();
  }

  private addZombieTypeVisual(zombie: ZombieActor): void {
    const colors: Record<ZombieType, Color3> = {
      walker: new Color3(0.36, 0.55, 0.28),
      runner: new Color3(0.75, 0.64, 0.14),
      brute: new Color3(0.55, 0.18, 0.12),
      boss: new Color3(0.48, 0.08, 0.26),
    };
    let material = this.zombieTypeMaterials.get(zombie.type);
    if (!material) {
      material = new PBRMaterial(`${zombie.type}-shared-tint-material`, this.scene);
      material.albedoColor = colors[zombie.type];
      material.emissiveColor = colors[zombie.type].scale(zombie.type === "walker" ? 0.55 : 0.75);
      material.emissiveIntensity = 1;
      material.freeze();
      this.zombieTypeMaterials.set(zombie.type, material);
    }
    let ringSource = this.zombieTypeRingSources.get(zombie.type);
    if (!ringSource) {
      ringSource = MeshBuilder.CreateTorus(`shared-${zombie.type}-type-tint`, { diameter: 1.45, thickness: zombie.type === "boss" ? 0.12 : 0.06, tessellation: 20 }, this.scene);
      ringSource.position.y = -1000;
      ringSource.material = material;
      ringSource.isPickable = false;
      this.zombieTypeRingSources.set(zombie.type, ringSource);
    }
    const ring = ringSource.createInstance(`${zombie.type}-type-tint`);
    ring.parent = zombie.root;
    ring.position.y = 0.08;
    ring.isPickable = false;
    if (zombie.type === "brute") {
      if (!this.zombieBrutePlateSource) {
        this.zombieBrutePlateSource = MeshBuilder.CreateBox("shared-brute-plate", { width: 0.62, height: 0.28, depth: 0.52 }, this.scene);
        this.zombieBrutePlateSource.position.y = -1000;
        this.zombieBrutePlateSource.material = material;
        this.zombieBrutePlateSource.isPickable = false;
      }
      for (const side of [-1, 1]) {
        const plate = this.zombieBrutePlateSource.createInstance(`${zombie.type}-plate-${side}`);
        plate.parent = zombie.root;
        plate.position.set(side * 0.48, 1.65, 0);
        plate.rotation.z = side * 0.25;
        plate.isPickable = false;
      }
    }
  }

  private allCows(): CowActor[] {
    return this.strongCow ? [this.cow, this.strongCow] : [this.cow];
  }

  private findNearestCow(origin: Vector3, range: number): CowActor | undefined {
    let nearest: CowActor | undefined;
    let bestDistance = range;
    for (const cow of this.allCows()) {
      if (!cow.alive) continue;
      const distance = Vector3.Distance(origin, cow.root.position);
      if (distance < bestDistance) {
        nearest = cow;
        bestDistance = distance;
      }
    }
    return nearest;
  }

  private zombieLabel(type: ZombieType): string {
    return type === "runner" ? "奔行者" : type === "brute" ? "蠻屍" : type === "boss" ? "巨型 Boss" : "行屍";
  }

  private monitorPerformance(): void {
    if (!this.started || document.hidden || this.visualEvidenceMode) return;
    if (this.performanceTier >= 2) {
      this.dropTierTwoDecorativeLayers();
      return;
    }
    const fps = this.engine.getFps();
    if (!Number.isFinite(fps) || fps <= 0) return;
    // R6 ships against a <=18 ms p95 gate, so the adaptive renderer must react
    // before a nominal 30 FPS average masks long frames.
    if (fps >= 55) {
      this.lowFpsSamples = Math.max(0, this.lowFpsSamples - 1);
      return;
    }
    this.lowFpsSamples += 1;
    if (this.lowFpsSamples < 2) return;

    this.lowFpsSamples = 0;
    this.performanceTier += 1;
    if (this.performanceTier === 1) this.dropExpensiveRenderingFeatures();
    if (this.performanceTier === 2) this.dropTierTwoDecorativeLayers();
    // The first fallback must already satisfy the p95 frame-time gate; average
    // FPS can hide regular 33 ms frames behind enough 16 ms frames.
    this.renderPixelRatio = this.performanceTier === 1 ? 0.55 : 0.4;
    this.engine.setHardwareScalingLevel(1 / this.renderPixelRatio);
    this.engine.resize();
    this.applyWeatherVisualProfile(true);
    // Honor the lower R15 density immediately instead of carrying several
    // seconds of already-emitted high-density flakes into the fallback tier.
    this.snowParticles?.reset();
    this.nearSnowParticles?.reset();
    for (const particles of this.ambientParticles) {
      particles.emitRate = this.performanceTier === 1 ? 12 : 6;
    }
  }

  private dropExpensiveRenderingFeatures(): void {
    // Recompile frozen PBR effects once without shadow defines, then freeze
    // them again after the render. Actor blobs preserve contact/readability.
    this.blobShadowsActive = true;
    this.scene.shadowsEnabled = false;
    if (this.shadows) {
      const realtimeShadows = this.shadows;
      this.shadows = undefined;
      realtimeShadows.dispose();
    }
    this.refreshFrozenMaterialEffects();
    for (const mesh of this.scene.meshes) mesh.receiveShadows = false;
    // The desktop camera exposes most of the forest ring at once. Keep a clear
    // low-poly silhouette while reducing only non-interactive detail; fences,
    // actors, physics/colliders, interactions, and combat state stay intact.
    for (const node of this.scene.transformNodes) {
      const pine = /^snow-pine-(\d+)$/u.exec(node.name);
      const rock = /^forest-rock-(\d+)$/u.exec(node.name);
      const cull = (pine && Number(pine[1]) % 9 !== 0) || (rock && Number(rock[1]) % 16 !== 0);
      if (!cull || !node.isEnabled()) continue;
      node.metadata = { ...(node.metadata ?? {}), r13AdaptiveCulled: true };
      node.setEnabled(false);
    }
    const adaptiveMeshCull = /(?:shop-holiday\/(?:cabin-wreath|lantern)\.glb|checkout-coin-|warm-window-|shop-campfire-stones|shop-custom\/butcher-stall\.glb-(?:CanopyStripe[135]|CounterBrace|FloorPlank|HamFat|Hook(?:Drop)?|PostBrace|PriceCoin|PriceMark)|butcher-checkout-(?:CrankHandle|DrawerPull|Key|Lamp)|shepherd-doghouse-(?:BackPlankSeam|Bone|DoorPost|Runner)|ballista-custom-tower-(?:LegBolt|RailCap|RuneSpoke|WindlassCrank|WindlassDrum|BowPlate|BowTip|BowInner|DeckRail|CrossBrace|SplayedLeg[13]|StoneStep|RuneInlay|BoltFletching)|frost-custom-tower-(?:OrbitShard[135]|FrostRune|GroundShard|CoreBand[AB]|SnowStep)|cannon-custom-tower-(?:TurntableTooth|FlameTongue[12]|BrazierGuard|CradlePin|TrunnionCap|FuseSocket|RecoilStop))/u;
    for (const mesh of this.scene.meshes) {
      if (!adaptiveMeshCull.test(mesh.name) || !mesh.isEnabled()) continue;
      mesh.metadata = { ...(mesh.metadata ?? {}), r13AdaptiveCulled: true };
      mesh.setEnabled(false);
    }
    this.cinematicPipeline?.dispose();
    this.cinematicPipeline = undefined;
    this.glow?.dispose();
    this.glow = undefined;
    this.shopLight.setEnabled(false);

    const actors: Actor[] = [
      ...(this.player ? [this.player] : []),
      ...(this.cow ? [this.cow] : []),
      ...(this.strongCow ? [this.strongCow] : []),
      ...this.customerVariants.values(),
      ...this.staff.values(),
      ...this.zombies.filter((zombie) => zombie.alive),
    ];
    for (const actor of actors) this.addActorShadows(actor);
  }

  private dropTierTwoDecorativeLayers(): void {
    // Preserve the gameplay silhouettes and all animated actors while removing
    // material-layer detail that multiplies draw calls across the wide desktop
    // view. Physics and interaction roots are separate from these render meshes.
    const tierTwoVisualCull = /(?:WorldFence(?:Rail|Gate)R13_R13 Shared Fence (?:Snow|Cut Wood)_Batch|stall-meat-\d+-(?:BoneRim|FatCap|MarblingA|MarblingB|SteakEdge)|ballista-custom-tower-(?:SplayedLeg[02]|StockNose|String-1|String1)|cannon-custom-tower-(?:BrazierCoals|BreechBand|CannonStep|CradleCrossbeam|CradleLeg-1|CradleLeg1|FlameTongue0|LitFuse|MidBand|MuzzleBand)|frost-custom-tower-(?:OrbitShard[024]|RuneDisc)|snow-pine-\d+-.+Shared Pine (?:Snow|Cut)_Batch|shop-custom\/world\/snowhouse-(?:door|window)\.glb-.+Snowhouse (?:Door (?:Brass|Iron|Snow)|Window (?:Iron|Snow))_Batch|shop-custom\/world\/snowhouse-shell\.glb-.+Snowhouse (?:Foundation|Roof Snow)_Batch|shop-custom\/butcher-stall\.glb-.+-material-batch-[1356]|butcher-checkout-material-batch-[123]|shepherd-doghouse-material-batch-[123]|player-weapon-smg-(?:SmgMagazine|SmgSight|SmgTriggerGuard))/u;
    for (const mesh of this.scene.meshes) {
      if (!tierTwoVisualCull.test(mesh.name) || !mesh.isEnabled()) continue;
      mesh.metadata = { ...(mesh.metadata ?? {}), r15AdaptiveCulled: true };
      mesh.setEnabled(false);
    }
    const repeatedFenceRoots = this.scene.meshes
      .filter((mesh) => /^(?:pasture|pasture-2)-fence-.+-__root__$/u.test(mesh.name))
      .sort((left, right) => left.name.localeCompare(right.name));
    for (const [index, mesh] of repeatedFenceRoots.entries()) {
      if (index % 2 === 0 || !mesh.isEnabled()) continue;
      mesh.metadata = { ...(mesh.metadata ?? {}), r15AdaptiveCulled: true };
      mesh.setEnabled(false);
    }
  }

  private applyQualityLevel(level: QualityLevel): void {
    const devicePixelRatio = Math.max(1, window.devicePixelRatio || 1);
    this.renderPixelRatio = level === "高" ? Math.min(1.25, devicePixelRatio) : Math.min(1, devicePixelRatio);
    this.engine.setHardwareScalingLevel(1 / this.renderPixelRatio);
    this.engine.resize();
    this.applyWeatherVisualProfile(true);
    if (level === "低") {
      this.dropExpensiveRenderingFeatures();
      this.applyWeatherVisualProfile(true);
      return;
    }
    this.restoreRealtimeRendering(level);
  }

  private restoreRealtimeRendering(level: Exclude<QualityLevel, "低">): void {
    this.blobShadowsActive = false;
    this.scene.shadowsEnabled = true;
    this.shopLight.setEnabled(true);
    for (const node of this.scene.transformNodes) {
      if (!node.metadata?.r13AdaptiveCulled) continue;
      node.setEnabled(true);
      delete node.metadata.r13AdaptiveCulled;
    }
    for (const mesh of this.scene.meshes) {
      if (!mesh.metadata?.r13AdaptiveCulled) continue;
      mesh.setEnabled(true);
      delete mesh.metadata.r13AdaptiveCulled;
    }
    if (!this.shadows) {
      this.shadows = new ShadowGenerator(level === "中" ? 1024 : 2048, this.sun, true);
      this.shadows.usePercentageCloserFiltering = true;
      this.shadows.filteringQuality = ShadowGenerator.QUALITY_MEDIUM;
      this.shadows.bias = 0.002;
      this.shadows.normalBias = 0.03;
    }
    this.shadows.setDarkness(0);
    const shadowMap = this.shadows.getShadowMap();
    if (shadowMap) shadowMap.refreshRate = 1;
    for (const mesh of this.scene.meshes) {
      if (mesh.name.endsWith("-blob-shadow")) {
        mesh.setEnabled(false);
        continue;
      }
      if (/wind-carved-snow|world-skirt|snow-path|attack-ring|type-tint/u.test(mesh.name)) {
        mesh.receiveShadows = true;
        continue;
      }
      this.castShadows(mesh);
    }
    this.refreshFrozenMaterialEffects();
    if (!this.glow) {
      this.glow = new GlowLayer("warm-window-glow", this.scene, { mainTextureFixedSize: 512, blurKernelSize: 48 });
      this.glow.intensity = 0.48;
    }
    if (!this.cinematicPipeline) {
      this.cinematicPipeline = new DefaultRenderingPipeline("storm-cinematic", true, this.scene, [this.camera]);
      this.cinematicPipeline.fxaaEnabled = true;
      this.cinematicPipeline.bloomEnabled = true;
      this.cinematicPipeline.bloomThreshold = 0.78;
      this.cinematicPipeline.bloomWeight = 0.2;
      this.cinematicPipeline.bloomKernel = 48;
      this.cinematicPipeline.imageProcessingEnabled = true;
      this.cinematicPipeline.imageProcessing.contrast = 1.08;
      this.cinematicPipeline.imageProcessing.exposure = 1.15;
    }
    this.cinematicPipeline.samples = level === "高" ? 2 : 1;
    this.applyWeatherVisualProfile(true);
  }

  private refreshFrozenMaterialEffects(): void {
    const materials = this.scene.materials.filter((material) => !material.name.includes("attack-ring") && !material.name.includes("blast"));
    for (const material of materials) {
      material.unfreeze();
      material.markAsDirty(Material.AllDirtyFlag);
    }
    this.scene.onAfterRenderObservable.addOnce(() => {
      for (const material of materials) material.freeze();
    });
  }

  private detectQuality(preference: QualityPreference): QualityLevel {
    return resolveQuality(preference, {
      smokeMode: this.smokeMode,
      userAgent: navigator.userAgent,
      maxTouchPoints: navigator.maxTouchPoints,
      coarsePointer: matchMedia("(pointer: coarse)").matches,
      viewportWidth: window.innerWidth,
      hardwareConcurrency: navigator.hardwareConcurrency,
      deviceMemory: (navigator as Navigator & { deviceMemory?: number }).deviceMemory,
    });
  }

  private findNearestZombie(origin: Vector3, range: number): ZombieActor | undefined {
    let nearest: ZombieActor | undefined;
    let bestDistance = range;
    for (const zombie of this.zombies) {
      if (!zombie.alive) continue;
      const distance = Vector3.Distance(origin, zombie.root.position);
      if (distance < bestDistance) {
        nearest = zombie;
        bestDistance = distance;
      }
    }
    return nearest;
  }

  private heightAt(x: number, z: number): number {
    const broad = Math.sin(x * 0.13) * 0.32 + Math.cos(z * 0.17) * 0.26;
    const drifts = Math.sin((x + z) * 0.37) * 0.09 + Math.cos(x * 0.51 - z * 0.23) * 0.065;
    const shopFlatten = Math.exp(-((x + 8) ** 2 + (z + 4) ** 2) / 38);
    const pastureFlatten = Math.exp(-((x - 8.5) ** 2 + (z - 3.7) ** 2) / 62);
    return (broad + drifts) * (1 - shopFlatten * 0.76) * (1 - pastureFlatten * 0.64);
  }

  private lerpAngle(from: number, to: number, amount: number): number {
    let delta = (to - from) % (Math.PI * 2);
    if (delta > Math.PI) delta -= Math.PI * 2;
    if (delta < -Math.PI) delta += Math.PI * 2;
    return from + delta * amount;
  }
}
